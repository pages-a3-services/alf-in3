let configPromise = null;

/** Vráti URL bez fragmentu (všetko za #) – na porovnávanie s konfiguráciou. */
function urlWithoutHash(url) {
  if (!url || typeof url !== "string") return url;
  const i = url.indexOf("#");
  return i === -1 ? url : url.slice(0, i);
}

/**
 * Porovnanie URL s podporou placeholdera ${id} v konfigurácii.
 * - ignoruje hash (#...)
 * - query (?...) sa musí zhodovať presne
 * - v path je segment "${id}" považovaný za wildcard pre jedno ID
 */
function urlsMatch(configUrl, url) {
  const configNoHash = urlWithoutHash(configUrl);
  const currentNoHash = urlWithoutHash(url);

  console.log("ALF autofill – porovnávam configUrl vs currentUrl:", {
    configUrl: configNoHash,
    currentUrl: currentNoHash,
  });

  try {
    const configU = new URL(configNoHash);
    const currentU = new URL(currentNoHash);

    // origin (protokol + host + port) musí sedieť
    if (configU.origin !== currentU.origin) {
      return false;
    }

    // query (?...) musí sedieť presne
    if (configU.search !== currentU.search) {
      return false;
    }

    // path rozbijeme na segmenty a porovnávame s podporou ${id}
    const safeDecode = (s) => {
      try {
        return decodeURIComponent(s);
      } catch {
        return s;
      }
    };

    const configParts = configU.pathname
      .split("/")
      .filter(Boolean)
      .map(safeDecode);
    const currentParts = currentU.pathname
      .split("/")
      .filter(Boolean)
      .map(safeDecode);

    if (configParts.length !== currentParts.length) {
      return false;
    }

    for (let i = 0; i < configParts.length; i++) {
      const cp = configParts[i];
      const up = currentParts[i];

      if (cp === "${id}") {
        // wildcard – hocijaký segment (napr. 764, 765, atď.)
        continue;
      }

      if (cp !== up) {
        return false;
      }
    }

    return true;
  } catch (e) {
    console.warn("ALF autofill – chyba pri parsovaní URL, padám na jednoduché porovnanie:", e);
    // Fallback: jednoduché porovnanie bez hash
    return configNoHash === currentNoHash;
  }
}

async function loadConfig() {
  if (!configPromise) {
    console.log("ALF autofill – načítavam data.json (prvý krát)");
    const url = chrome.runtime.getURL("data.json");
    configPromise = fetch(url)
      .then((res) => res.json())
      .then((json) => {
        if (json && Array.isArray(json.data)) {
          const urls = json.data.map((e) => e && e.url).filter(Boolean);
          console.log("ALF autofill – načítané URL z data.json:", urls);
        }
        return json;
      })
      .catch((err) => {
        console.error("ALF autofill – chyba pri načítaní data.json:", err);
        return null;
      });
  } else {
    console.log("ALF autofill – používam cache data.json");
  }

  return configPromise;
}

function findConfigForUrl(config, url) {
  const urlNoHash = urlWithoutHash(url);
  console.log("ALF autofill – hľadám konfiguráciu pre URL (bez #):", urlNoHash);

  if (!config || !Array.isArray(config.data)) {
    console.log("ALF autofill – konfigurácia je prázdna alebo chýba pole data");
    return null;
  }

  const entry = config.data.find(
    (e) => e && typeof e.url === "string" && urlsMatch(e.url, url)
  );

  if (entry) {
    console.log("ALF autofill – nájdená konfigurácia pre URL:", entry.url);
  } else {
    console.log("ALF autofill – žiadna konfigurácia pre túto URL");
  }

  return entry || null;
}

function applyConfigToDom(configForUrl) {
  if (!configForUrl || !Array.isArray(configForUrl["data-test-id"])) {
    console.log("ALF autofill – applyConfigToDom: žiadne polia na vyplnenie");
    return;
  }

  const fields = configForUrl["data-test-id"];
  console.log("ALF autofill – aplikujem konfiguráciu, počet polí:", fields.length);

  let filledCount = 0;

  for (const field of fields) {
    if (!field || typeof field !== "object") continue;

    const id = field.id;
    const value = field.value ?? "";

    if (!id) continue;

    const selectorId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(id) : id;
    const el = document.querySelector(`[data-test-id="${selectorId}"]`);

    if (!el) {
      console.warn("ALF autofill – nenašiel som element pre data-test-id:", id);
      continue;
    }

    console.log("ALF autofill – vyplňujem pole", id, "hodnotou:", value);

    // Špeciálne správanie pre input type="radio"/"checkbox"
    if (el instanceof HTMLInputElement && (el.type === "radio" || el.type === "checkbox")) {
      // Pre rádio/checkbox:
      // - explicitné "false"/false/"0"/0 -> odškrtnúť
      // - akákoľvek iná hodnota (vrátane stringov) -> zaškrtnúť
      let shouldCheck;
      if (value === false || value === "false" || value === 0 || value === "0") {
        shouldCheck = false;
      } else {
        shouldCheck = value !== undefined && value !== null;
      }

      el.checked = shouldCheck;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else if ("value" in el) {
      el.value = value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      el.textContent = value;
    }

    filledCount++;
  }

  if (filledCount > 0) {
    console.log(
      `ALF autofill – vyplnených ${filledCount} polí pre URL:`,
      location.href
    );
  }
}

async function applyAutofillForCurrentUrl() {
  try {
    console.log("ALF autofill – spúšťam pre URL:", location.href);

    const config = await loadConfig();
    const configForUrl = findConfigForUrl(config, location.href);

    if (!configForUrl) {
      return;
    }

    console.log("ALF autofill – aplikujem predvyplnenie");
    applyConfigToDom(configForUrl);
  } catch (err) {
    console.error("ALF autofill – chyba pri spracovaní autofillu:", err);
  }
}

// Sprístupníme funkciu globálne pre ďalšie skripty (napr. main.js)
window.autofill = {
  applyAutofillForCurrentUrl: applyAutofillForCurrentUrl,
};

