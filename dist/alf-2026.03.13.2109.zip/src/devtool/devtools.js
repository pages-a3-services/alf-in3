// Ukladanie / čítanie URL z chrome.storage
const STORAGE_KEY_API_URL = "alf2_api_url";
const GET_SCENARIOS_PATH = "getAlfScenarios";
const POST_SCENARIO_PATH = "getAlfScenario";

function $(id) {
  return document.getElementById(id);
}

function buildScenarioUrl(baseUrl, path) {
  if (!baseUrl || typeof baseUrl !== "string") return null;
  const base = baseUrl.trim().replace(/\/$/, "");
  const segment = path || GET_SCENARIOS_PATH;
  return base ? `${base}/${segment}` : null;
}

function setStatus(el, text, type) {
  el.textContent = text || "";
  el.classList.remove("error", "success");
  if (type) {
    el.classList.add(type);
  }
}

async function loadStoredUrl() {
  return new Promise((resolve) => {
    try {
      chrome.storage.sync.get([STORAGE_KEY_API_URL], (res) => {
        if (chrome.runtime.lastError) {
          console.warn("ALF2 DevTools – chyba pri čítaní storage:", chrome.runtime.lastError);
          resolve(null);
          return;
        }
        resolve(res[STORAGE_KEY_API_URL] || null);
      });
    } catch (e) {
      console.warn("ALF2 DevTools – výnimka pri čítaní storage:", e);
      resolve(null);
    }
  });
}

async function saveUrl(url) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.sync.set({ [STORAGE_KEY_API_URL]: url }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        resolve();
      });
    } catch (e) {
      reject(e);
    }
  });
}

async function fetchOptions(url) {
  const res = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/json",
    },
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }

  const data = await res.json();

  if (!Array.isArray(data)) {
    throw new Error("Očakávané pole [{id, value}, ...]");
  }

  return data;
}

async function fetchScenarios(baseUrl) {
  const url = buildScenarioUrl(baseUrl, GET_SCENARIOS_PATH);
  if (!url) {
    throw new Error("Chýba base URL");
  }

  const res = await fetch(url, {
    method: "GET",
    headers: { Accept: "application/json" },
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }

  const data = await res.json();
  if (Array.isArray(data)) {
    return data;
  }
  if (data && Array.isArray(data.scenarios)) {
    return data.scenarios;
  }
  if (data && Array.isArray(data.data)) {
    return data.data;
  }
  throw new Error("Očakávané pole alebo objekt so scenarios/data");
}

function getInspectedTabUrl() {
  return new Promise((resolve, reject) => {
    const inspected = chrome.devtools?.inspectedWindow;
    if (!inspected) {
      reject(new Error("DevTools inspectedWindow nie je k dispozícii."));
      return;
    }
    // 1) Eval v kontexte stránky – funguje pre bežné weby, nepotrebuje tabs permission
    inspected.eval("location.href", (result, exception) => {
      if (exception) {
        // 2) Fallback: tab z tabId (napr. chrome:// stránky blokujú eval)
        const tabId = inspected.tabId;
        if (tabId == null) {
          reject(new Error(exception.value || "Nepodarilo sa získať URL stránky."));
          return;
        }
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError) {
            reject(new Error(exception.value || chrome.runtime.lastError.message));
            return;
          }
          resolve(tab?.url || "");
        });
        return;
      }
      resolve(typeof result === "string" ? result : "");
    });
  });
}

async function postAlfScenario(baseUrl, filePath, url) {
  const endpoint = buildScenarioUrl(baseUrl, POST_SCENARIO_PATH);
  if (!endpoint) {
    throw new Error("Chýba base URL");
  }
  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({ filePath, url }),
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}: ${text || res.statusText}`);
  }
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function fillSelect(selectEl, list) {
  selectEl.innerHTML = "";

  if (!list || list.length === 0) {
    const opt = document.createElement("option");
    opt.value = "";
    opt.textContent = "(Žiadne položky z API)";
    selectEl.appendChild(opt);
    return;
  }

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "(Vyber položku)";
  selectEl.appendChild(placeholder);

  for (const item of list) {
    if (!item || typeof item !== "object") continue;
    const id = item.id != null ? String(item.id) : "";
    const value = item.value != null ? String(item.value) : "";
    if (!id && !value) continue;

    const opt = document.createElement("option");
    opt.value = id;
    opt.textContent = value || id;
    opt.dataset.id = id;
    selectEl.appendChild(opt);
  }
}

async function loadScenariosIntoSelect() {
  const apiUrlInput = $("apiUrl");
  const apiSelect = $("apiSelect");
  const selectStatus = $("selectStatus");

  const baseUrl = apiUrlInput.value.trim();
  if (!baseUrl) {
    setStatus(selectStatus, "Zadaj base URL a ulož ju.", "error");
    return;
  }

  setStatus(selectStatus, "Načítavam…", null);
  try {
    const list = await fetchScenarios(baseUrl);
    fillSelect(apiSelect, list);
    setStatus(
      selectStatus,
      list.length ? `Načítaných ${list.length} položiek.` : "Žiadne položky.",
      "success",
    );
  } catch (e) {
    console.error("ALF2 DevTools – chyba pri načítaní scenárov:", e);
    setStatus(selectStatus, e.message || "Chyba pri načítaní.", "error");
    fillSelect(apiSelect, []);
  }
}

async function init() {
  const apiUrlInput = $("apiUrl");
  const saveUrlBtn = $("saveUrlBtn");
  const apiStatus = $("apiStatus");
  const apiSelect = $("apiSelect");
  const selectStatus = $("selectStatus");

  // Načítanie uloženého URL pri štarte
  const storedUrl = await loadStoredUrl();
  if (storedUrl) {
    apiUrlInput.value = storedUrl;
    setStatus(apiStatus, "Načítaná uložená URL.", "success");
    await loadScenariosIntoSelect();
  }

  saveUrlBtn.addEventListener("click", async () => {
    const url = apiUrlInput.value.trim();
    if (!url) {
      setStatus(apiStatus, "Prosím zadaj URL.", "error");
      return;
    }

    try {
      await saveUrl(url);
      setStatus(apiStatus, "URL uložená.", "success");
      await loadScenariosIntoSelect();
    } catch (e) {
      console.error("ALF2 DevTools – chyba pri ukladaní URL:", e);
      setStatus(apiStatus, "Chyba pri ukladaní URL.", "error");
    }
  });

  const loadScenariosBtn = $("loadScenariosBtn");
  if (loadScenariosBtn) {
    loadScenariosBtn.addEventListener("click", loadScenariosIntoSelect);
  }

  apiSelect.addEventListener("change", async () => {
    const filePath = apiSelect.value;
    const resultStatus = $("resultStatus");
    const apiResult = $("apiResult");

    if (!filePath) {
      setStatus(selectStatus, "Nevybraná žiadna položka.", null);
      setStatus(resultStatus, "", null);
      apiResult.textContent = "";
      return;
    }

    setStatus(selectStatus, `Vybraná položka: ${filePath}`, "success");
    const baseUrl = apiUrlInput.value.trim();
    if (!baseUrl) {
      setStatus(resultStatus, "Zadaj base URL.", "error");
      apiResult.textContent = "";
      return;
    }

    setStatus(resultStatus, "Volám POST getAlfScenario…", null);
    apiResult.textContent = "";
    try {
      const inspectedUrl = await getInspectedTabUrl();
      const result = await postAlfScenario(baseUrl, filePath, inspectedUrl);
      setStatus(resultStatus, "OK", "success");
      apiResult.textContent =
        typeof result === "string"
          ? result
          : JSON.stringify(result, null, 2);
    } catch (e) {
      console.error("ALF2 DevTools – chyba POST getAlfScenario:", e);
      setStatus(resultStatus, e.message || "Chyba volania.", "error");
      apiResult.textContent = e.message || String(e);
    }
  });
}

document.addEventListener("DOMContentLoaded", init);

