// Spustí sa v kontexte devtools_page a vytvorí vlastný panel ALF2.
chrome.devtools.panels.create("ALF2", "", "devtool/devtools-panel.html", function () {});

