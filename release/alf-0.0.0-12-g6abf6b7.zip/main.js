/**
 * Porovná aktuálnu URL so stepUrl.
 * - currentUrl: plná URL stránky (origin + path + query).
 * - stepUrl: len path + query (napr. "/app/.../{id}/...?krok=1"), {id} = wildcard pre ľubovoľný segment.
 * Vráti true, ak path a query sedia (v current path sa číselné ID ignoruje, t.j. normalizuje na {id}).
 */
function urlMatchesStep(currentUrl, stepUrl) {
  if (!currentUrl || !stepUrl) return false;
  try {
    const curr = new URL(currentUrl);
    const currentPath = curr.pathname;
    const currentSearch = curr.search || "";

    const stepPath = stepUrl.indexOf("?") >= 0 ? stepUrl.slice(0, stepUrl.indexOf("?")) : stepUrl;
    const stepSearch = stepUrl.indexOf("?") >= 0 ? stepUrl.slice(stepUrl.indexOf("?")) : "";

    const stepSegments = stepPath.split("/").filter(Boolean);
    const currSegments = currentPath.split("/").filter(Boolean);
    if (stepSegments.length !== currSegments.length) return false;

    const idIndex = stepSegments.indexOf("{id}");
    const normalizedCurr = currSegments.map((seg, i) => (i === idIndex ? "{id}" : seg)).join("/");
    const normalizedPath = "/" + normalizedCurr + currentSearch;
    const stepPathAndQuery = (stepPath.startsWith("/") ? stepPath : "/" + stepPath) + stepSearch;
    return normalizedPath === stepPathAndQuery;
  } catch (e) {
    return false;
  }
}

function autofillScenarioForCurrentUrl(scenario) {
  if (!Array.isArray(scenario) || !scenario.length) {
    return { filledCount: 0, matchedStepUrl: null };
  }

  const currentUrl = location.href;

  for (const step of scenario) {
    if (!step || !step.url || !step.map || typeof step.map !== "object") continue;
    const stepUrl = String(step.url).trim();
    if (!urlMatchesStep(currentUrl, stepUrl)) continue;

    const entries = Object.entries(step.map);
    let filledCount = 0;

    for (const [dataTestId, value] of entries) {
      if (dataTestId == null || dataTestId === "") continue;
      const selectorId =
        typeof CSS !== "undefined" && CSS.escape ? CSS.escape(String(dataTestId)) : String(dataTestId);
      const el = document.querySelector(`[data-test-id="${selectorId}"]`);
      if (!el) continue;

      const valueStr = value != null ? String(value) : "";

      if ("value" in el) {
        el.value = valueStr;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        el.textContent = valueStr;
      }
      filledCount++;
    }

    if (filledCount > 0) {
      console.log("ALF2 scenario autofill (content script)", {
        currentUrl,
        stepUrl,
        filledCount,
      });
      return { filledCount, matchedStepUrl: stepUrl };
    }

    break;
  }

  return { filledCount: 0, matchedStepUrl: null };
}

// Spracovanie akcií zo scenára z DevTools (ALF2)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "ALF2_RUN_SCENARIO_ACTION") {
    return;
  }

  // #region agent log – entry (content script received message?)
  try {
    chrome.runtime.sendMessage(
      {
        type: "ALF2_DEBUG_LOG",
        payload: {
          location: "main.js:listener-entry",
          message: "Content script received ALF2_RUN_SCENARIO_ACTION",
          data: {
            hasScenario: Array.isArray(message.scenario),
            scenarioLen: Array.isArray(message.scenario) ? message.scenario.length : 0,
            stepIndex: message.stepIndex,
            currentUrl: typeof location !== "undefined" && location.href ? location.href.slice(0, 90) : "",
          },
          timestamp: Date.now(),
          hypothesisId: "E",
        },
      },
      () => {},
    );
  } catch (e) {
    // ignore
  }
  // #endregion agent log

  const scenario = message.scenario;
  const stepIndex = message.stepIndex;
  if (!Array.isArray(scenario) || stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
    sendResponse && sendResponse({ ok: false, reason: "missing_scenario_or_index" });
    return;
  }

  const stepForClick = scenario[stepIndex];
  const actionName = stepForClick.action || stepForClick.actions;
  if (!actionName) {
    // #region agent log – chýbajúca action v kroku
    try {
      chrome.runtime.sendMessage(
        {
          type: "ALF2_DEBUG_LOG",
          payload: {
            location: "main.js:missing_action",
            message: "Step has no action/actions",
            data: {
              stepIndex,
              stepKeys: stepForClick && typeof stepForClick === "object"
                ? Object.keys(stepForClick)
                : null,
              stepRaw: stepForClick,
            },
            timestamp: Date.now(),
            hypothesisId: "G",
          },
        },
        () => {},
      );
    } catch (e) {
      // ignore
    }
    // #endregion agent log

    sendResponse &&
      sendResponse({
        ok: false,
        reason: "missing_action",
        stepDebug: {
          stepIndex,
          stepKeys:
            stepForClick && typeof stepForClick === "object"
              ? Object.keys(stepForClick)
              : null,
          stepRaw: stepForClick,
        },
      });
    return;
  }

  // #region agent log
  chrome.runtime.sendMessage(
    {
      type: "ALF2_DEBUG_LOG",
      payload: {
        location: "main.js:ALF2_RUN_SCENARIO_ACTION",
        message: "Content script received Action",
        data: {
          stepIndex,
          actionName,
          scenarioLength: scenario.length,
          currentUrl: location.href ? location.href.slice(0, 100) : null,
        },
        timestamp: Date.now(),
        hypothesisId: "C",
      },
    },
    () => {},
  );
  // #endregion agent log

  try {
    let handledAutofill = false;

    const { filledCount } = autofillScenarioForCurrentUrl(scenario);
    if (filledCount > 0) {
      handledAutofill = true;
    }

    // 2) Klik na element podľa action kroku na stepIndex (krok, ktorý sa má vykonať)
    const selector = `[data-test-id="${actionName}"]`;
    const all = Array.prototype.slice.call(document.querySelectorAll("[data-test-id]"));
    const matches = Array.prototype.slice.call(document.querySelectorAll(selector));

    // #region agent log
    chrome.runtime.sendMessage(
      {
        type: "ALF2_DEBUG_LOG",
        payload: {
          location: "main.js:selector-check",
          message: "Element lookup for action",
          data: {
            actionName,
            matchCount: matches.length,
            allIdsSample: all.slice(0, 15).map((el) => el.getAttribute("data-test-id")),
          },
          timestamp: Date.now(),
          hypothesisId: "D",
        },
      },
      () => {},
    );
    // #endregion agent log

    let clicked = false;
    if (matches[0]) {
      const candidate = matches[0];
      const clickable =
        (typeof candidate.click === "function" && candidate) ||
        candidate.querySelector(
          'button, [role="button"], a, input[type="submit"], input[type="button"]',
        );

      if (clickable && typeof clickable.click === "function") {
        clickable.click();
        clicked = true;
      }
    }

    // 3) Po krátkom čase po CLick skúsime ešte raz autofill – pre prípad, že sa navigovalo na novú URL
    //    (typický flow: Action -> nová stránka -> automatický autofill podľa map).
    setTimeout(() => {
      try {
        autofillScenarioForCurrentUrl(scenario);
      } catch (e) {
        console.error("ALF2 content script – chyba pri delayed autofill:", e);
      }
    }, 800);

    sendResponse &&
      sendResponse({
        ok: true,
        found: !!matches[0],
        clicked,
        autofilled: handledAutofill,
        matchCount: matches.length,
        allIdsSample: all.slice(0, 20).map((el) => el.getAttribute("data-test-id")),
      });
  } catch (e) {
    console.error("ALF2 content script – chyba pri spracovaní scenára:", e);
    sendResponse && sendResponse({ ok: false, error: String(e) });
  }

  // keep channel open only synchronously
  return true;
});

