/**
 * Minimal background script for forwarding ALF debug logs from content script
 * to the debug ingest server (content script fetch may be blocked by CORS).
 */
const DEBUG_INGEST_URL = "http://127.0.0.1:7319/ingest/390e3f63-5274-4b37-b2da-0fa74ce2b1c7";

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message && message.type === "ALF_DEBUG_LOG" && message.payload) {
    fetch(DEBUG_INGEST_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Debug-Session-Id": "81c1cd",
      },
      body: JSON.stringify({
        ...message.payload,
        sessionId: "81c1cd",
        timestamp: message.payload.timestamp || Date.now(),
      }),
    }).catch(() => {});
    sendResponse({ ok: true });
  }
  return true;
});
