chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  // Po vyčistení debug inštrumentácie už tieto správy ďalej neposielame
  if (message && message.type === "ALF_DEBUG_LOG") {
    sendResponse && sendResponse({ ok: true });
    return true;
  }
  return false;
});
