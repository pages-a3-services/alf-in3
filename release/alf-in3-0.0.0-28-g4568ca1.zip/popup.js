document.addEventListener("DOMContentLoaded", () => {
  const versionEl = document.getElementById("version");
  const nameRowEl = document.getElementById("nameRow");

  try {
    const manifest = chrome.runtime.getManifest();
    if (versionEl) {
      versionEl.textContent = manifest.version || "neznáma";
    }
  } catch (e) {
    if (versionEl) {
      versionEl.textContent = "chyba pri čítaní verzie";
    }
  }

  const openDevtoolsBtn = document.getElementById("openDevtools");
  if (openDevtoolsBtn) {
    openDevtoolsBtn.addEventListener("click", () => {
      const url = chrome.runtime.getURL("devtool/devtools-panel.html");
      chrome.tabs.create({ url });
    });
  }
});

