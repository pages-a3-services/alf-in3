chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message && message.type === "ALF_DEBUG_LOG") {
    sendResponse && sendResponse({ ok: true });
    return true;
  }
  return false;
});
