/**
 * Porovná aktuálnu URL so stepUrl.
 * - currentUrl: plná URL stránky (origin + path + query).
 * - stepUrl: len path + query (napr. "/app/.../{id}/...?krok=1"), {id} = wildcard pre ľubovoľný segment.
 * Vráti true, ak:
 *   - path po nahradení {id} sedí
 *   - všetky query parametre zo stepUrl sú prítomné v aktuálnej URL s rovnakými hodnotami
 *     (aktuálna URL môže mať navyše ďalšie parametre).
 */
function urlMatchesStep(currentUrl, stepUrl) {
  if (!currentUrl || !stepUrl) return false;
  const stepUrlNormalized = String(stepUrl).trim().toLowerCase();
  if (stepUrlNormalized === "login") {
    return true;
  }
  try {
    const curr = new URL(currentUrl);
    const currentPath = curr.pathname;
    const currentSearch = curr.search || "";

    const qPos = stepUrl.indexOf("?");
    const stepPath = qPos >= 0 ? stepUrl.slice(0, qPos) : stepUrl;
    const stepSearch = qPos >= 0 ? stepUrl.slice(qPos) : "";

    const stepSegments = stepPath.split("/").filter(Boolean);
    const currSegments = currentPath.split("/").filter(Boolean);
    if (stepSegments.length !== currSegments.length) return false;

    const idIndex = stepSegments.indexOf("{id}");
    const normalizedCurr = currSegments.map((seg, i) => (i === idIndex ? "{id}" : seg)).join("/");
    const normalizedPath = "/" + normalizedCurr + currentSearch;
    const stepPathAndQuery = (stepPath.startsWith("/") ? stepPath : "/" + stepPath) + stepSearch;

    // Path (vrátane query stringu) musí mať rovnakú štruktúru, ale query môže mať v currentUrl
    // ďalšie parametre navyše – stačí, že všetky parametre zo stepUrl sú prítomné.
    if (stepPath.startsWith("/")) {
      if (!normalizedPath.startsWith(stepPath)) {
        return false;
      }
    }

    if (!stepSearch) {
      // stepUrl nemá query – stačí zhodná path (už overená vyššie cez segments)
      return true;
    }

    const stepParams = new URLSearchParams(stepSearch);
    const currParams = new URLSearchParams(currentSearch);

    for (const [key, value] of stepParams.entries()) {
      if (!currParams.has(key)) return false;
      // ak v stepUrl je konkrétna hodnota, musí sedieť
      if (value !== "" && currParams.get(key) !== value) {
        return false;
      }
    }

    return true;
  } catch (e) {
    return false;
  }
}

// Pamätáme si, pre ktorú URL už prebehol úspešný autofill,
// aby sme pri ďalšom stlačení Action na tej istej stránke
// znova neprepisovali polia.
let lastAutofillUrl = null;
const PENDING_LOGIN_AUTOFILL_KEY = "alfPendingLoginAutofill";

function setPendingLoginAutofill(scenario, stepIndex) {
  try {
    chrome.storage.local.set(
      {
        [PENDING_LOGIN_AUTOFILL_KEY]: {
          scenario,
          stepIndex,
          createdAt: Date.now(),
        },
      },
      () => {},
    );
  } catch {
    // ignore
  }
}

function runPendingLoginAutofillOnLoad() {
  try {
    chrome.storage.local.get([PENDING_LOGIN_AUTOFILL_KEY], (result) => {
      const pending = result && result[PENDING_LOGIN_AUTOFILL_KEY];
      if (!pending || typeof pending !== "object") return;

      const scenario = pending.scenario;
      const stepIndex = pending.stepIndex;
      const createdAt = pending.createdAt || 0;

      // Bezpečnostná poistka proti starému pending stavu.
      if (Date.now() - createdAt > 2 * 60 * 1000) {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        return;
      }

      if (!Array.isArray(scenario) || stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        return;
      }

      const step = scenario[stepIndex];
      const stepUrl = step && step.url != null ? String(step.url).trim().toLowerCase() : "";
      if (stepUrl !== "login") {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        return;
      }

      try {
        autofillScenarioForCurrentUrl(scenario, stepIndex);
      } catch {
        // ignore
      } finally {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
      }
    });
  } catch {
    // ignore
  }
}

/**
 * Vyplní polia podľa mapy kroku scenára, ak aktuálna URL sedí na krok na danom indexe.
 * Kroky idú vždy zaradom – používa sa len stepIndex, nie prehľadávanie podľa URL.
 */
function autofillScenarioForCurrentUrl(scenario, stepIndex) {
  if (!Array.isArray(scenario) || !scenario.length) {
    return { filledCount: 0, matchedStepUrl: null };
  }
  if (stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
    return { filledCount: 0, matchedStepUrl: null };
  }

  const currentUrl = location.href;
  const step = scenario[stepIndex];
  if (!step || !step.url || !step.map || typeof step.map !== "object") {
    return { filledCount: 0, matchedStepUrl: null };
  }

  const stepUrl = String(step.url).trim();
  if (!urlMatchesStep(currentUrl, stepUrl)) {
    // URL v scenári sa nezhoduje s aktuálnou URL – scenár je nesprávne nastavený.
    // Vypíšeme jasnú chybu a ukončíme spracovanie aktuálneho kroku.
    console.error("ALF scenario – URL nesedí na stepIndex", {
      stepIndex,
      expectedStepUrl: stepUrl,
      currentUrl,
    });
    throw new Error("ALF scenario – URL v kroku scenára sa nezhoduje s aktuálnou stránkou");
  }

  {
    const entries = Object.entries(step.map);
    let filledCount = 0;
    let scheduledRestAfterToggle = false;

    const fillEntry = (dataTestId, value) => {
      if (dataTestId == null || dataTestId === "") return false;

      const rawKey = String(dataTestId);
      const hashPos = rawKey.indexOf("#");
      const lookupKey = hashPos >= 0 ? rawKey.slice(0, hashPos) : rawKey;
      const suffix = hashPos >= 0 ? rawKey.slice(hashPos + 1).toLowerCase() : "";
      const markers = suffix
        ? suffix
            .split(";")
            .map((s) => s.trim())
            .filter(Boolean)
        : [];
      const isToggleKeyLocal = markers.includes("toggle");
      const isSearchKeyLocal = markers.includes("search");

      const selectorId =
        typeof CSS !== "undefined" && CSS.escape ? CSS.escape(lookupKey) : lookupKey;
      const byDataTestId = document.querySelector(`[data-test-id="${selectorId}"]`);
      const byId = document.getElementById(lookupKey);
      const el = byDataTestId || byId;
      if (!el) return false;

      const valueStr = value != null ? String(value) : "";

      // Rozlíšenie podľa typu elementu
      if (el instanceof HTMLInputElement) {
        const t = el.type ? el.type.toLowerCase() : "";

        if (t === "checkbox" || t === "radio") {
          if (typeof el.click === "function") {
            el.click();
          }

          filledCount++;
          return true;
        } else {
          el.value = valueStr;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
        }
      } else if (el instanceof HTMLTextAreaElement) {
        el.value = valueStr;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (el instanceof HTMLSelectElement) {
        el.value = valueStr;
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if ("value" in el) {
        // Iné elementy s .value (napr. custom komponenty)
        el.value = valueStr;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        // Pre wrappery (napr. div/span s data-test-id):
        if (el.querySelector) {
          // 1) Toggle: vnorený checkbox/radio/role=checkbox
          if (isToggleKeyLocal) {
            const innerToggle = el.querySelector(
              'input[type="checkbox"], input[type="radio"], [role="checkbox"]',
            );
            if (innerToggle && typeof innerToggle.click === "function") {
              innerToggle.click();
              filledCount++;
              return true;
            }
          }

          // 2) Search: vnorený textový/combobox input + tlačidlo "vyhladat"
          if (isSearchKeyLocal) {
            const searchInput =
              el.querySelector('input[type="text"][role="combobox"]') ||
              el.querySelector('input[type="search"]') ||
              el.querySelector('input[type="text"]');

            if (searchInput) {
              searchInput.value = valueStr;
              searchInput.dispatchEvent(new Event("input", { bubbles: true }));
              searchInput.dispatchEvent(new Event("change", { bubbles: true }));
            }

            const searchButton = el.querySelector('[data-test-id="vyhladat"]');
            if (searchButton && typeof searchButton.click === "function") {
              searchButton.click();
            }

            // Po vyhľadaní (po krátkom oneskorení) automaticky zvolíme PRVÚ ne-disable-nutú možnosť
            setTimeout(() => {
              const listbox =
                el.querySelector(".multiselect-options") ||
                el.querySelector('[role="listbox"]');
              if (!listbox) return;

              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );

              const target = options.find(
                (opt) =>
                  !opt.classList || !opt.classList.contains("is-disabled"),
              );

              if (target && typeof target.click === "function") {
                target.click();
              }
            }, 1000);

            filledCount++;
            return true;
          }

          // 3) Combobox (custom multiselect) – vyber možnosť podľa textu/aria-label
          const comboboxRoot =
            el.getAttribute("role") === "combobox"
              ? el
              : el.querySelector('[role="combobox"], .multiselect-wrapper');
          if (comboboxRoot) {
            const listbox =
              el.querySelector(".multiselect-options") ||
              el.querySelector('[role="listbox"]') ||
              comboboxRoot.nextElementSibling;
            if (listbox) {
              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );
              const target = options.find((opt) => {
                const labelText =
                  (opt.getAttribute && opt.getAttribute("aria-label")) ||
                  opt.textContent ||
                  "";
                const id = opt.id || "";
                // napr. "...-multiselect-option-vydatazenaty" -> "vydatazenaty"
                let idValue = "";
                const idParts = id.split("-option-");
                if (idParts.length === 2) {
                  idValue = idParts[1];
                }

                const wanted = valueStr.trim().toLowerCase();
                const labelNorm = labelText.trim().toLowerCase();
                const idNorm = idValue.trim().toLowerCase();

                return wanted === labelNorm || (idNorm && wanted === idNorm);
              });

              if (target && typeof target.click === "function") {
                target.click();
                filledCount++;
                return true;
              }
            }
          }
        }

        // Fallback – pre obyčajné wrappery bez špeciálnej logiky
        el.textContent = valueStr;
      }
      filledCount++;
      return true;
    };

    entries.forEach(([dataTestId, value], index) => {
      const keyStr = dataTestId != null ? String(dataTestId) : "";
      const hashIndex = keyStr.indexOf("#");
      const suffix = hashIndex >= 0 ? keyStr.slice(hashIndex + 1).toLowerCase() : "";
      const markers = suffix
        ? suffix
            .split(";")
            .map((s) => s.trim())
            .filter(Boolean)
        : [];
      const isToggleKey = markers.includes("toggle");

      if (isToggleKey && !scheduledRestAfterToggle) {
        fillEntry(dataTestId, value);
        scheduledRestAfterToggle = true;

        // Po zapnutí toggle počkáme 1s, aby sa odomkli ďalšie polia,
        // a potom pokračujeme vo vyplňovaní zvyšných viet kľúčov v poradí.
        setTimeout(() => {
          try {
            for (let i = index + 1; i < entries.length; i++) {
              const [nextKey, nextValue] = entries[i];
              fillEntry(nextKey, nextValue);
            }
          } catch (e) {
            console.error("ALF scenario autofill – delayed fill error", e);
          }
        }, 1000);
      } else {
        fillEntry(dataTestId, value);
      }
    });

  if (filledCount > 0) {
    lastAutofillUrl = currentUrl;
    return { filledCount, matchedStepUrl: stepUrl };
  }

  return { filledCount: 0, matchedStepUrl: null };
  }
}

// Spracovanie akcií zo scenára z DevTools (ALF)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "ALF_RUN_SCENARIO_ACTION") {
    return;
  }

  const scenario = message.scenario;
  const stepIndex = message.stepIndex;
  if (!Array.isArray(scenario) || stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
    sendResponse && sendResponse({ ok: false, reason: "missing_scenario_or_index" });
    return;
  }

  const stepForClick = scenario[stepIndex];
  const actionName = stepForClick.action || stepForClick.actions;
  if (!actionName) {
    sendResponse && sendResponse({ ok: false, reason: "missing_action" });
    return;
  }

  try {
    let handledAutofill = false;

    // Ak sme už pre túto URL úspešne robili autofill (napr. pri predchádzajúcom kroku
    // alebo cez delayed autofill po navigácii), pri ďalšom stlačení Action na tej
    // istej stránke už polia neprepisujeme.
    let filledCount = 0;
    if (location.href !== lastAutofillUrl) {
      const result = autofillScenarioForCurrentUrl(scenario, stepIndex);
      filledCount = result.filledCount;
      if (filledCount > 0) {
        handledAutofill = true;
      }
    }

    const doActionClick = (phase) => {
      // 2) Klik na element podľa action kroku na stepIndex (krok, ktorý sa má vykonať)
      const actionKey = String(actionName);
      const selector = `[data-test-id="${actionKey}"]`;
      const all = Array.prototype.slice.call(document.querySelectorAll("[data-test-id]"));
      let matches = Array.prototype.slice.call(document.querySelectorAll(selector));
      if (matches.length === 0) {
        const byId = document.getElementById(actionKey);
        if (byId) matches = [byId];
      }

      let clicked = false;
      if (matches[0]) {
        const candidate = matches[0];
        const clickable =
          (typeof candidate.click === "function" && candidate) ||
          candidate.querySelector(
            'button, [role="button"], a, input[type="submit"], input[type="button"]',
          );

        if (clickable && typeof clickable.click === "function") {
          clickable.click();
          clicked = true;
        }
      }
      return { clicked, matchCount: matches.length, allIdsSample: all.slice(0, 50).map((el) => el.getAttribute("data-test-id")) };
    };

    // Ak sme práve menili hodnoty (autofill), necháme Vue/vee-validate dobehnúť re-render
    // a až potom klikneme na "pokracovat". (Nie timeout, iba synchronizácia na event loop/render.)
    const clickResultPromise = handledAutofill
      ? Promise.resolve().then(
          () =>
            new Promise((resolve) => {
              requestAnimationFrame(() => {
                requestAnimationFrame(() => resolve(doActionClick("deferred-raf2")));
              });
            }),
        )
      : Promise.resolve(doActionClick("immediate"));

    // 3) Po krátkom čase po Click skúsime autofill nasledujúceho kroku – pre prípad, že sa navigovalo na novú URL
    //    (typický flow: Action -> nová stránka -> automatický autofill podľa mapy ďalšieho kroku).
    const nextStepIndex = stepIndex + 1;
    const nextStep = Array.isArray(scenario) && nextStepIndex >= 0 && nextStepIndex < scenario.length
      ? scenario[nextStepIndex]
      : null;
    const nextStepUrl = nextStep && nextStep.url != null ? String(nextStep.url).trim().toLowerCase() : "";
    if (nextStepUrl === "login") {
      setPendingLoginAutofill(scenario, nextStepIndex);
    }
    setTimeout(() => {
      try {
        autofillScenarioForCurrentUrl(scenario, nextStepIndex);
      } catch {
        // ignore delayed autofill errors
      }
    }, 800);

    clickResultPromise.then((clickResult) => {
      sendResponse &&
        sendResponse({
          ok: true,
          found: clickResult.matchCount > 0,
          clicked: !!clickResult.clicked,
          autofilled: handledAutofill,
          matchCount: clickResult.matchCount,
          allIdsSample: clickResult.allIdsSample,
        });
    });
  } catch (e) {
    console.error("ALF content script – chyba pri spracovaní scenára:", e);
    sendResponse && sendResponse({ ok: false, error: String(e) });
  }

  // keep channel open only synchronously
  return true;
});

runPendingLoginAutofillOnLoad();

