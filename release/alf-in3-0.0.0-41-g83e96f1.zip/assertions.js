/**
 * ALF Assertions
 * ---------------
 * Engine pre asertácie v scenároch.:
 *
 *   assert:
 *     - isAuthenticated(ferko.mrkva)
 *     - isTrue(healthy)
 *     - isEqual(status-field, aktívny)
 *     - hasSuccessMessage("Záznam bol uložený")
 *     - hasCount(row-item, 3)
 */

// ----- DOM helpers -----

function alfFindEl(testId) {
  if (testId == null || testId === "") return null;
  const key = String(testId);
  const escaped = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(key) : key;
  return (
    document.querySelector(`[data-test-id="${escaped}"]`) ||
    document.getElementById(key) ||
    null
  );
}

function alfGetElValue(el) {
  if (!el) return "";
  if (
    el instanceof HTMLInputElement ||
    el instanceof HTMLTextAreaElement ||
    el instanceof HTMLSelectElement
  ) {
    return el.value;
  }
  return el.textContent.trim();
}

// ----- Parser -----

/**
 * Rozdelí argumenty volania po čiarkach. Rešpektuje "..." a '...' úvodzovky —
 * čiarka vo vnútri reťazca nerozdeľuje. Úvodzovky sa z výslednej hodnoty odstránia.
 */
function splitAssertionArgs(argsStr) {
  const result = [];
  let current = "";
  let inQuotes = false;
  let quoteChar = "";

  for (let i = 0; i < argsStr.length; i++) {
    const ch = argsStr[i];
    if (inQuotes) {
      if (ch === quoteChar) {
        inQuotes = false;
      } else {
        current += ch;
      }
    } else if (ch === '"' || ch === "'") {
      inQuotes = true;
      quoteChar = ch;
    } else if (ch === ",") {
      result.push(current.trim());
      current = "";
    } else {
      current += ch;
    }
  }

  const last = current.trim();
  if (last !== "" || result.length > 0) {
    result.push(last);
  }
  return result;
}

/**
 * Parsuje jeden záznam assertácie. Prijíma:
 *   - string:  "isEqual(foo, bar)"  →  { fn: "isEqual", args: ["foo", "bar"], raw: "..." }
 *   - object:  { fn: "isEqual", args: ["foo", "bar"] }  (legacy fallback)
 * Vráti null pri nevalidnom vstupe.
 */
function parseAssertion(input) {
  if (input && typeof input === "object" && !Array.isArray(input) && input.fn) {
    return {
      fn: String(input.fn),
      args: Array.isArray(input.args) ? input.args.map((a) => (a == null ? "" : String(a))) : [],
      raw: null,
    };
  }

  if (typeof input !== "string") return null;

  const raw = input.trim();
  const match = raw.match(/^(\w+)\s*\(([\s\S]*)\)\s*$/);
  if (!match) return null;

  const fn = match[1];
  const argsStr = match[2].trim();
  const args = argsStr === "" ? [] : splitAssertionArgs(argsStr);
  return { fn, args, raw };
}

// ----- Assertions -----

const ALF_ASSERTIONS = {
  /** Používateľ je prihlásený (existuje tlačidlo "odhlasit"). Ak je zadaný user,
   *  hľadá sa jeho meno v DOM elementoch s data-test-id obsahujúcim "user"/"pouzivatel"/"prihlaseny". */
  isAuthenticated(user) {
    const logoutBtn = document.querySelector('[data-test-id="odhlasit"]');
    if (!logoutBtn) return false;
    if (user != null && String(user).trim()) {
      const needle = String(user).trim().toLowerCase();
      const userEls = document.querySelectorAll(
        '[data-test-id*="user"], [data-test-id*="pouzivatel"], [data-test-id*="prihlaseny"]',
      );
      for (const el of userEls) {
        if (el.textContent.toLowerCase().includes(needle)) return true;
      }
      return false;
    }
    return true;
  },

  /** Používateľ NIE je prihlásený – existuje tlačidlo prihlásenia alebo registrácie. */
  isUnauthenticated() {
    return !!(
      document.querySelector('[data-test-id="prihlasenie"]') ||
      document.querySelector('[data-test-id="registracia"]')
    );
  },

  /** Aktuálna URL sedí na zadaný vzor (rovnaký wildcard formát ako kroky scenára). */
  isUrl(url) {
    if (!url) return false;
    // urlMatchesStep je definovaná v main.js, zdieľaný scope (late binding).
    return urlMatchesStep(location.href, String(url).trim());
  },

  /** Element je zaškrtnutý / aria-checked=true / má truthy hodnotu. */
  isTrue(testId) {
    const el = alfFindEl(testId);
    if (!el) return false;
    if (el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio")) {
      return el.checked;
    }
    const ariaChecked = el.getAttribute("aria-checked");
    if (ariaChecked !== null) return ariaChecked === "true";
    const val = alfGetElValue(el);
    return Boolean(val) && val !== "false" && val !== "0";
  },

  /** Opak isTrue. */
  isFalse(testId) {
    const el = alfFindEl(testId);
    if (!el) return false;
    if (el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio")) {
      return !el.checked;
    }
    const ariaChecked = el.getAttribute("aria-checked");
    if (ariaChecked !== null) return ariaChecked !== "true";
    const val = alfGetElValue(el);
    return !val || val === "false" || val === "0";
  },

  /** Hodnota (alebo textContent) elementu sa rovná zadanému reťazcu. */
  isEqual(testId, value) {
    const el = alfFindEl(testId);
    if (!el) return false;
    return alfGetElValue(el) === String(value != null ? value : "");
  },

  /** Opak isEqual (non-existent element považujeme za "nie rovný"). */
  isNotEqual(testId, value) {
    const el = alfFindEl(testId);
    if (!el) return true;
    return alfGetElValue(el) !== String(value != null ? value : "");
  },

  /** Element chýba alebo má prázdnu hodnotu / text. */
  isEmpty(testId) {
    const el = alfFindEl(testId);
    if (!el) return true;
    return alfGetElValue(el) === "";
  },

  /** Opak isEmpty. */
  isNotEmpty(testId) {
    const el = alfFindEl(testId);
    if (!el) return false;
    return alfGetElValue(el) !== "";
  },

  /** Toast/alert s success triedou (voliteľne obsahujúci daný text). */
  hasSuccessMessage(text) {
    const all = Array.from(
      document.querySelectorAll(
        '[role="alert"], .toast, .notification, [class*="toast"], [class*="notification"], [class*="snackbar"]',
      ),
    );
    const pool = all.filter((el) => {
      const cls = (el.className || "").toLowerCase();
      return (
        cls.includes("success") ||
        cls.includes("is-success") ||
        el.dataset.type === "success"
      );
    });
    const candidates = pool.length > 0 ? pool : all;
    if (!text) return candidates.length > 0;
    const needle = String(text).trim().toLowerCase();
    return candidates.some((el) => el.textContent.trim().toLowerCase().includes(needle));
  },

  /** Toast/alert s error triedou alebo .govuk-error-summary (voliteľne obsahujúci text). */
  hasErrorMessage(text) {
    const all = Array.from(
      document.querySelectorAll(
        '[role="alert"], .govuk-error-summary, .toast, [class*="toast"], [class*="error"], [class*="notification"]',
      ),
    );
    const pool = all.filter((el) => {
      const cls = (el.className || "").toLowerCase();
      return (
        cls.includes("error") ||
        cls.includes("is-error") ||
        el.dataset.type === "error"
      );
    });
    const candidates = pool.length > 0 ? pool : all;
    if (!text) return candidates.length > 0;
    const needle = String(text).trim().toLowerCase();
    return candidates.some((el) => el.textContent.trim().toLowerCase().includes(needle));
  },

  /** V govuk-form-group rodičovi poľa existuje chybová hláška (voliteľne s textom). */
  hasValidationError(testId, text) {
    const el = alfFindEl(testId);
    if (!el) return false;
    const parent =
      el.closest(".govuk-form-group, .form-group, .field, .input-wrapper") ||
      el.parentElement;
    if (!parent) return false;
    const errorEl = parent.querySelector(
      '.govuk-error-message, .error-message, .field-error, [class*="error-message"], [class*="validation-error"]',
    );
    if (!errorEl) return false;
    if (!text) return true;
    return errorEl.textContent
      .trim()
      .toLowerCase()
      .includes(String(text).trim().toLowerCase());
  },

  /** Počet elementov s daným data-test-id sedí. */
  hasCount(testId, number) {
    if (!testId) return false;
    const key = String(testId);
    const escaped = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(key) : key;
    return (
      document.querySelectorAll(`[data-test-id="${escaped}"]`).length === Number(number)
    );
  },

  /** Element s daným data-test-id existuje v DOM (alias pre "identifikator"). */
  exists(testId) {
    return !!alfFindEl(testId);
  },
};

// ----- Runner -----

/**
 * Spustí zoznam assertácií. Každá môže byť string ("isEqual(foo, bar)") alebo
 * objekt ({ fn, args }) pre spätnú kompatibilitu.
 *
 * Vráti { passed: bool, results: [{ fn, args, passed, error?, raw? }] }
 */
function runAssertions(assertions) {
  if (!Array.isArray(assertions) || assertions.length === 0) {
    return { passed: true, results: [] };
  }

  const results = assertions.map((entry) => {
    const parsed = parseAssertion(entry);
    if (!parsed) {
      return {
        fn: "",
        args: [],
        passed: false,
        error: "Nevalidný syntax assertácie",
        raw: typeof entry === "string" ? entry : JSON.stringify(entry),
      };
    }

    const fn = ALF_ASSERTIONS[parsed.fn];
    if (typeof fn !== "function") {
      return {
        fn: parsed.fn,
        args: parsed.args,
        passed: false,
        error: `Neznáma assertácia: "${parsed.fn}"`,
        raw: parsed.raw,
      };
    }

    try {
      return {
        fn: parsed.fn,
        args: parsed.args,
        passed: !!fn(...parsed.args),
        raw: parsed.raw,
      };
    } catch (e) {
      return {
        fn: parsed.fn,
        args: parsed.args,
        passed: false,
        error: String(e),
        raw: parsed.raw,
      };
    }
  });

  return { passed: results.every((r) => r.passed), results };
}
