// Ukladanie / čítanie URL z chrome.storage
const STORAGE_KEY_API_URL = "ALF_api_url";
const GET_SCENARIOS_PATH = "+/alf-engine/api/getAlfScenarios";
const POST_SCENARIO_PATH = "+/alf-engine/api/getAlfScenario";

function $(id) {
  return document.getElementById(id);
}

/**
 * Log do UI panela + do devtools konzoly.
 * level: "info" | "warn" | "error"
 */
function alfLog(level, ...args) {
  const consoleFn =
    level === "error" ? console.error : level === "warn" ? console.warn : console.log;
  consoleFn(...args);

  const logArea = $("logArea");
  if (!logArea) return;

  const line = document.createElement("div");
  line.className = `log-line log-${level}`;
  const time = new Date().toLocaleTimeString();
  const msg = args
    .map((a) => {
      if (typeof a === "string") return a;
      try {
        return JSON.stringify(a);
      } catch {
        return String(a);
      }
    })
    .join(" ");
  line.textContent = `[${time}] ${msg}`;
  logArea.insertBefore(line, logArea.firstChild);

  // Obmedz počet riadkov v paneli
  while (logArea.children.length > 200) {
    logArea.removeChild(logArea.lastChild);
  }
}

function buildScenarioUrl(baseUrl, path) {
  if (!baseUrl || typeof baseUrl !== "string") return null;
  const base = baseUrl.trim().replace(/\/$/, "");
  const segment = path || GET_SCENARIOS_PATH;
  return base ? `${base}/${segment}` : null;
}

async function loadStoredUrl() {
  return new Promise((resolve) => {
    try {
      chrome.storage.sync.get([STORAGE_KEY_API_URL], (res) => {
        if (chrome.runtime.lastError) {
          alfLog("warn", "ALF DevTools – chyba pri čítaní storage:", chrome.runtime.lastError);
          resolve(null);
          return;
        }
        resolve(res[STORAGE_KEY_API_URL] || null);
      });
    } catch (e) {
      alfLog("warn", "ALF DevTools – výnimka pri čítaní storage:", e);
      resolve(null);
    }
  });
}

async function saveUrl(url) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.sync.set({ [STORAGE_KEY_API_URL]: url }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        resolve();
      });
    } catch (e) {
      reject(e);
    }
  });
}

async function fetchOptions(url) {
  const res = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/json",
    },
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }

  const data = await res.json();

  if (!Array.isArray(data)) {
    throw new Error("Očakávané pole [{id, value}, ...]");
  }

  return data;
}

async function fetchScenarios(baseUrl) {
  const baseUrl_ = buildScenarioUrl(baseUrl, GET_SCENARIOS_PATH);
  if (!baseUrl_) {
    throw new Error("Chýba base URL");
  }
  const url = `${baseUrl_}?_t=${Date.now()}`;

  const res = await fetch(url, {
    method: "GET",
    headers: { Accept: "application/json" },
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }

  const data = await res.json();
  if (Array.isArray(data)) {
    return data;
  }
  if (data && Array.isArray(data.scenarios)) {
    return data.scenarios;
  }
  if (data && Array.isArray(data.data)) {
    return data.data;
  }
  throw new Error("Očakávané pole alebo objekt so scenarios/data");
}


async function postAlfScenario(baseUrl, filePath) {
  const endpoint = buildScenarioUrl(baseUrl, POST_SCENARIO_PATH);
  if (!endpoint) {
    throw new Error("Chýba base URL");
  }
  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({ filePath }),
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}: ${text || res.statusText}`);
  }
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

async function getInspectedTabUrl() {
  return new Promise((resolve, reject) => {
    const inspected = chrome.devtools?.inspectedWindow;
    if (!inspected) {
      reject(new Error("DevTools inspectedWindow nie je k dispozícii."));
      return;
    }

    // 1) Pokus o získanie URL priamo z kontextu stránky
    inspected.eval("location.href", (result, exception) => {
      if (exception) {
        // 2) Fallback: cez tabId (napr. ak ide o špeciálnu stránku)
        const tabId = inspected.tabId;
        if (tabId == null) {
          reject(
            new Error(exception.value || "Nepodarilo sa získať URL stránky."),
          );
          return;
        }
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError) {
            reject(
              new Error(
                exception.value || chrome.runtime.lastError.message,
              ),
            );
            return;
          }
          resolve(tab?.url || "");
        });
        return;
      }
      resolve(typeof result === "string" ? result : "");
    });
  });
}

function fillSelect(selectEl, list) {
  selectEl.innerHTML = "";

  if (!list || list.length === 0) {
    const opt = document.createElement("option");
    opt.value = "";
    opt.textContent = "(Žiadne položky z API)";
    selectEl.appendChild(opt);
    return;
  }

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "(Vyber položku)";
  selectEl.appendChild(placeholder);

  for (const item of list) {
    if (!item || typeof item !== "object") continue;
    const id = item.id != null ? String(item.id) : "";
    const value = item.value != null ? String(item.value) : "";
    if (!id && !value) continue;

    const opt = document.createElement("option");
    opt.value = id;
    opt.textContent = value || id;
    opt.dataset.id = id;
    selectEl.appendChild(opt);
  }
}

/** Base URL A3 – načítaná zo storage (nastavuje sa v popup). */
let currentBaseUrl = null;

async function loadScenariosIntoSelect() {
  const apiSelect = $("apiSelect");
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) {
    return;
  }
  try {
    const list = await fetchScenarios(baseUrl);
    alfLog("info", `ALF DevTools – načítaných scenárov: ${list.length}`);
    fillSelect(apiSelect, list);
  } catch (e) {
    alfLog("error", "ALF DevTools – chyba pri načítaní scenárov:", e && e.message ? e.message : e);
    fillSelect(apiSelect, []);
  }
}

let lastScenario = null;
let lastScenarioIndex = -1;
let lastScenarioFilePath = null;

function updateActionButtonState() {
  const runScenarioStepBtn = $("runScenarioStepBtn");
  const resetScenarioBtn = $("resetScenarioBtn");
  const apiSelect = $("apiSelect");
  if (!runScenarioStepBtn && !resetScenarioBtn) return;

  // Žiadny vybraný scenár v comboboxe
  if (!apiSelect || !apiSelect.value || !String(apiSelect.value).trim()) {
    if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
    if (resetScenarioBtn) resetScenarioBtn.disabled = true;
    return;
  }

  if (
    !Array.isArray(lastScenario) ||
    lastScenarioIndex < 0 ||
    lastScenarioIndex >= lastScenario.length
  ) {
    if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
    if (resetScenarioBtn) resetScenarioBtn.disabled = true;
    return;
  }

  // Krok je v rozsahu – Action aj Reset povolíme.
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = false;
  if (resetScenarioBtn) resetScenarioBtn.disabled = false;
}

/** Vráti delay v ms podľa mapy kroku: #toggle/#search → 2s, iná map → 1s, inak 0.5s */
function getDelayMsForStep(step) {
  if (!step || typeof step !== "object") return 500;
  const mapKeys = step.map && typeof step.map === "object" ? Object.keys(step.map) : [];
  const hasDelayedKeys = mapKeys.some(
    (k) => /#toggle/i.test(String(k)) || /#search/i.test(String(k)),
  );
  if (hasDelayedKeys) return 2000;
  if (mapKeys.length > 0) return 1000;
  return 500;
}

/** Pri vstupe na aktuálny krok: zablokuje Action na getDelayMsForStep(aktuálny krok). */
function applyDelayForCurrentStep() {
  if (
    !Array.isArray(lastScenario) ||
    lastScenarioIndex < 0 ||
    lastScenarioIndex >= lastScenario.length
  ) {
    updateActionButtonState();
    return;
  }
  const step = lastScenario[lastScenarioIndex];
  const delayMs = getDelayMsForStep(step);
  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  if (delayMs > 0) {
    setTimeout(() => updateActionButtonState(), delayMs);
  } else {
    updateActionButtonState();
  }
}

function renderAssertionResults(assertResults) {
  const section = $("assertSection");
  const container = $("assertResult");
  const summary = $("assertSummary");
  if (!section || !container) return;

  if (!assertResults || !Array.isArray(assertResults.results) || assertResults.results.length === 0) {
    section.style.display = "none";
    return;
  }

  const results = assertResults.results;
  const passedCount = results.filter((r) => r.passed).length;
  const total = results.length;

  if (summary) {
    summary.textContent = `(${passedCount}/${total})`;
    summary.style.color = passedCount === total ? "#3fb950" : "#f85149";
  }

  container.innerHTML = "";
  for (const r of results) {
    const div = document.createElement("div");
    div.className = `assert-item ${r.passed ? "pass" : "fail"}`;

    const icon = r.passed ? "✓" : "✗";
    const label =
      r.raw ||
      (r.fn ? `${r.fn}(${(r.args || []).join(", ")})` : "(neznáma assertácia)");
    const err = r.error ? ` — ${r.error}` : "";

    div.textContent = `${icon} ${label}${err}`;
    container.appendChild(div);
  }

  section.style.display = "block";
}

function renderCurrentStepInfo(indexOverride) {
  const apiResult = $("apiResult");
  if (!apiResult) return;

  if (!Array.isArray(lastScenario) || lastScenario.length === 0) {
    apiResult.textContent = "Žiadny načítaný scenár.";
    return;
  }

  const totalSteps = lastScenario.length;
  const idx =
    typeof indexOverride === "number" && !Number.isNaN(indexOverride)
      ? indexOverride
      : lastScenarioIndex;

  if (idx < 0 || idx >= totalSteps) {
    apiResult.textContent = "Žiadne ďalšie kroky scenára.";
    return;
  }

  const step = lastScenario[idx] || {};
  const actionName = step.action || step.actions || null;
  const map = step.map && typeof step.map === "object" ? step.map : null;

  const lines = [
    `Step ${idx + 1}/${totalSteps}`,
    `name: ${step.name || "-"}`,
    `url: ${step.url || "-"}`,
    `action: ${actionName || "-"}`,
  ];

  const asserts = Array.isArray(step.assert) ? step.assert : [];
  if (asserts.length > 0) {
    lines.push("assert:");
    for (const a of asserts) {
      lines.push(`  - ${a}`);
    }
  }

  if (map && Object.keys(map).length > 0) {
    lines.push("map:");
    for (const [k, v] of Object.entries(map)) {
      const valStr = v === null || v === undefined ? "" : String(v);
      lines.push(`  ${k}: ${valStr}`);
    }
  } else {
    lines.push("map: (žiadne položky)");
  }

  apiResult.textContent = lines.join("\n");
}

function extractScenarios(result) {
  if (!result || typeof result !== "object") return null;
  const feature =
    (result.feature && typeof result.feature === "object" && result.feature) ||
    (result.alf && typeof result.alf === "object" && result.alf) ||
    null;
  if (!feature || !Array.isArray(feature.scenario)) return null;
  return feature.scenario;
}

/** URL na ktorú presmerovať po výbere scenára. Uprednostňuje feature.start.url; výsledok sa skladá ako origin aktuálneho tabu + path (ak nie je plná URL). */
function getStartUrl(result) {
  if (!result || typeof result !== "object") return null;
  let pathOrUrl = null;
  if (
    result.feature &&
    typeof result.feature === "object" &&
    result.feature.start &&
    typeof result.feature.start === "object" &&
    typeof result.feature.start.url === "string"
  ) {
    pathOrUrl = result.feature.start.url.trim();
  }
  if (!pathOrUrl && typeof result.startUrl === "string") pathOrUrl = result.startUrl.trim();
  if (!pathOrUrl && result.feature?.startUrl) pathOrUrl = String(result.feature.startUrl).trim();
  if (!pathOrUrl && result.alf?.startUrl) pathOrUrl = String(result.alf.startUrl).trim();
  return pathOrUrl || null;
}

async function loadScenario() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");

  const filePath = apiSelect.value;

  if (!filePath) {
    apiResult.textContent = "";
    return;
  }
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) {
    apiResult.textContent = "";
    return;
  }
  try {
    const result = await postAlfScenario(baseUrl, filePath);
    const scenarios = extractScenarios(result);
    if (!scenarios || scenarios.length === 0) {
      return;
    }

    const startObj =
      (result && result.start) ||
      (result && result.alf && result.alf.start) ||
      (result && result.feature && result.feature.start) ||
      null;

    const combinedSteps = [];
    if (startObj && typeof startObj === "object") {
      combinedSteps.push({
        name: startObj.name || "start",
        url:
          (typeof startObj.url === "string" && startObj.url) ||
          getStartUrl(result) ||
          null,
        action: startObj.action || startObj.actions || null,
        map: startObj.map || null,
      });
    }
    for (const s of scenarios) {
      if (s && typeof s === "object") {
        combinedSteps.push(s);
      }
    }

    // uložíme scenár (vrátane start kroku) pre Action
    lastScenario = combinedSteps;
    lastScenarioFilePath = filePath;
    lastScenarioIndex = 0;

    // zobraz aktuálny krok (prvý krok scenára)
    renderCurrentStepInfo(0);
    applyDelayForCurrentStep();

    // badge: 0 / počet krokov
    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;

      if (chrome.action && tabId != null && totalSteps) {
        chrome.action.setBadgeBackgroundColor({ color: "#2563eb", tabId });
        chrome.action.setBadgeText({
          text: `0/${totalSteps}`,
          tabId,
        });
      }

      const stepBadge = $("stepBadge");
      if (stepBadge && totalSteps) {
        stepBadge.textContent = `0/${totalSteps}`;
      }
    } catch (e) {
      alfLog("warn", "ALF DevTools – nepodarilo sa nastaviť badge:", e && e.message ? e.message : e);
    }

    // presmerovanie na startUrl
    const startUrl = getStartUrl(result);
    if (!startUrl) {
      return;
    }
    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      if (tabId != null) {
        const currentHrefResult = await getInspectedTabUrl().catch(() => null);
        let targetOrigin = null;
        if (currentHrefResult) {
          try {
            const current = new URL(currentHrefResult);
            targetOrigin = current.origin;
          } catch {
            targetOrigin = null;
          }
        }
        let targetUrl;
        if (startUrl.startsWith("http") || !targetOrigin) {
          targetUrl = startUrl;
        } else {
          const path = String(startUrl).trim();
          targetUrl = path.startsWith("/") ? targetOrigin + path : targetOrigin + "/" + path;
        }
        chrome.tabs.update(tabId, { url: targetUrl });
      }
    } catch (navErr) {
      alfLog("warn", "ALF DevTools – nepodarilo sa presmerovať stránku:", navErr && navErr.message ? navErr.message : navErr);
    }
  } catch (e) {
    alfLog("error", "ALF DevTools – chyba POST getAlfScenario:", e && e.message ? e.message : e);
    apiResult.textContent = e.message || String(e);
  }
}

async function runScenarioStep() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");

  const filePath = apiSelect.value;

  if (!filePath || !lastScenario || lastScenarioFilePath !== filePath) {
    apiResult.textContent = "Vyber scenár v comboboxe – načíta sa a presmeruje na start.";
    return;
  }

  if (
    !Array.isArray(lastScenario) ||
    lastScenarioIndex < 0 ||
    lastScenarioIndex >= lastScenario.length
  ) {
    apiResult.textContent = "Žiadne ďalšie kroky scenára.";
    return;
  }

  const step = lastScenario[lastScenarioIndex];
  if (!step) {
    apiResult.textContent = "Neplatný krok scenára.";
    return;
  }

  const actionName = step.action || step.actions;
  if (!actionName) {
    apiResult.textContent = "Krok scenára nemá definovanú action/actions.";
    lastScenarioIndex += 1;
    return;
  }

  const inspected = chrome.devtools?.inspectedWindow;
  const tabId = inspected?.tabId;
  if (tabId == null) {
    apiResult.textContent = "TabId nie je k dispozícii.";
    return;
  }

  // Pri kliknutí iba zakážeme tlačidlo (anti double-click). Blokovanie podľa mapy
  // sa aplikuje pri vstupe na krok v callbacku (applyDelayForCurrentStep).
  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;

  // Vyčisti výsledky assertácií z predošlého kroku pred novým behom.
  renderAssertionResults(null);

  alfLog("info", `ALF DevTools – runScenarioStep [${lastScenarioIndex+1}] action=${actionName} url=${step.url || "-"}`);

  chrome.tabs.sendMessage(
    tabId,
    { type: "ALF_RUN_SCENARIO_ACTION", scenario: lastScenario, stepIndex: lastScenarioIndex },
    (response) => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "ALF DevTools – chyba pri posielaní správy:", chrome.runtime.lastError.message || chrome.runtime.lastError);
        return;
      }

      if (!response || !response.ok) {
        alfLog(
          "warn",
          "ALF DevTools – content script nevedel spracovať action:",
          actionName,
          response,
        );
        return;
      }

      // Zobraz výsledky assertácií (aj keď response.found je false)
      renderAssertionResults(response.assertResults || null);

      if (!response.found) {
        alfLog(
          "warn",
          "ALF DevTools – nenašiel som element s data-test-id=",
          actionName,
        );
        return;
      }

      // krok sa považuje za spracovaný, posunieme index a aktualizujeme badge
      const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;
      const nextIndex = Math.min(lastScenarioIndex + 1, totalSteps);
      try {
        if (chrome.action && totalSteps && tabId != null) {
          chrome.action.setBadgeText({
            text: `${nextIndex}/${totalSteps}`,
            tabId,
          });
        }
        const stepBadge = $("stepBadge");
        if (stepBadge && totalSteps) {
          stepBadge.textContent = `${nextIndex}/${totalSteps}`;
        }
      } catch (e) {
        alfLog("warn", "ALF DevTools – nepodarilo sa aktualizovať badge:", e && e.message ? e.message : e);
      }

      lastScenarioIndex = nextIndex;

      // aktualizuj panel Current step – ďalší krok v poradí
      renderCurrentStepInfo(nextIndex);
      // Blokovanie Action podľa mapy NOVÉHO kroku (ten, na ktorý sme práve vstúpili)
      applyDelayForCurrentStep();
    },
  );
}

async function resetScenario() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const filePath = apiSelect && apiSelect.value ? String(apiSelect.value) : "";

  if (!filePath || !Array.isArray(lastScenario) || lastScenarioFilePath !== filePath) {
    if (apiResult) {
      apiResult.textContent = "Vyber scenár v comboboxe – načíta sa a presmeruje na start.";
    }
    updateActionButtonState();
    return;
  }

  lastScenarioIndex = 0;
  renderCurrentStepInfo(0);
  renderAssertionResults(null);
  applyDelayForCurrentStep();

  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    const totalSteps = lastScenario.length;
    if (chrome.action && tabId != null && totalSteps) {
      chrome.action.setBadgeText({ text: `0/${totalSteps}`, tabId });
    }
    const stepBadge = $("stepBadge");
    if (stepBadge && totalSteps) {
      stepBadge.textContent = `0/${totalSteps}`;
    }
  } catch (e) {
    alfLog("warn", "ALF DevTools – nepodarilo sa resetnúť badge:", e && e.message ? e.message : e);
  }

  // Pri reset-e sa vrátime aj na URL prvého kroku (start krok scenára).
  try {
    const startStep = Array.isArray(lastScenario) && lastScenario.length > 0 ? lastScenario[0] : null;
    const startUrl =
      startStep && typeof startStep.url === "string" ? startStep.url.trim() : "";
    if (!startUrl) return;

    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;

    const currentHrefResult = await getInspectedTabUrl().catch(() => null);
    let targetOrigin = null;
    if (currentHrefResult) {
      try {
        const current = new URL(currentHrefResult);
        targetOrigin = current.origin;
      } catch {
        targetOrigin = null;
      }
    }

    let targetUrl;
    if (startUrl.startsWith("http") || !targetOrigin) {
      targetUrl = startUrl;
    } else {
      targetUrl = startUrl.startsWith("/") ? targetOrigin + startUrl : targetOrigin + "/" + startUrl;
    }

    chrome.tabs.update(tabId, { url: targetUrl });
  } catch (e) {
    alfLog("warn", "ALF DevTools – nepodarilo sa presmerovať po reset:", e && e.message ? e.message : e);
  }
}

async function init() {
  const apiSelect = $("apiSelect");

  // Verzia rozšírenia v hlavičke DevTools panelu
  try {
    const versionEl = $("alfVersion");
    if (versionEl && chrome.runtime && chrome.runtime.getManifest) {
      const manifest = chrome.runtime.getManifest();
      if (manifest && manifest.version) {
        versionEl.textContent = `v${manifest.version}`;
      }
    }
  } catch (e) {
    // tiché zlyhanie – verzia je len kozmetická informácia
  }

  // A3 URL sa nastavuje v popup; tu len načítame zo storage
  currentBaseUrl = await loadStoredUrl() || "https://a3.ugkk.dev/";
  await loadScenariosIntoSelect();

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) {
    runScenarioStepBtn.disabled = true;
    runScenarioStepBtn.addEventListener("click", runScenarioStep);
  }
  const resetScenarioBtn = $("resetScenarioBtn");
  if (resetScenarioBtn) {
    resetScenarioBtn.disabled = true;
    resetScenarioBtn.addEventListener("click", resetScenario);
  }
  const refreshScenariosBtn = $("refreshScenariosBtn");
  if (refreshScenariosBtn) {
    refreshScenariosBtn.addEventListener("click", () => loadScenariosIntoSelect());
  }
  const logClearBtn = $("logClearBtn");
  if (logClearBtn) {
    logClearBtn.addEventListener("click", () => {
      const logArea = $("logArea");
      if (logArea) logArea.innerHTML = "";
    });
  }

  apiSelect.addEventListener("change", () => {
    const apiResult = $("apiResult");

    // Zmena výberu automaticky načíta scenár a presmeruje na startUrl
    apiResult.textContent = "";
    renderAssertionResults(null);
    lastScenario = null;
    lastScenarioIndex = -1;
    lastScenarioFilePath = null;

    // vymaž badge pri zmene scenára, pred novým načítaním
    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      if (tabId != null) {
        chrome.action.setBadgeText({ text: "", tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge) {
        stepBadge.textContent = "0/0";
      }
    } catch (e) {
      alfLog("warn", "ALF DevTools – nepodarilo sa vyčistiť badge:", e && e.message ? e.message : e);
    }

    loadScenario();
    updateActionButtonState();
  });
}

document.addEventListener("DOMContentLoaded", init);

