/**
 * ALF Assertions
 * ---------------
 * Engine pre asertácie v scenároch.:
 *
 *   assert: |
 *     isAuthenticated("ferko.mrkva")
 *     isTrue(navrhovatel.fyzickaOsoba.hasKorespondencnaAdresa)
 *     isEqual("status-field", "aktívny")
 *     hasSuccessMessage("Záznam bol uložený")
 *     countByTestIdIs("row-item", 3)
 */

// ----- DOM helpers -----

function alfFindEl(testId) {
  if (testId == null || testId === "") return null;
  const key = String(testId);
  const escaped = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(key) : key;
  return (
    document.querySelector(`[data-test-id="${escaped}"]`) ||
    document.getElementById(key) ||
    null
  );
}

function alfGetElValue(el) {
  if (!el) return "";
  if (
    el instanceof HTMLInputElement ||
    el instanceof HTMLTextAreaElement ||
    el instanceof HTMLSelectElement
  ) {
    return el.value;
  }
  return el.textContent.trim();
}

function alfExists(testId) {
  return !!alfFindEl(testId);
}

function alfRequireEl(testId, assertionName) {
  const el = alfFindEl(testId);
  if (el) return el;
  const key = testId == null ? "" : String(testId);
  const suffix = assertionName ? ` (${assertionName})` : "";
  throw new Error(`Not found datatestid: ${key}${suffix}`);
}

function alfIsVisible(el) {
  if (!el || !el.isConnected) return false;
  if (el.hidden) return false;
  if (el.getAttribute("aria-hidden") === "true") return false;

  const style = window.getComputedStyle(el);
  if (style.display === "none") return false;
  if (style.visibility === "hidden" || style.visibility === "collapse") return false;

  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

// ----- Parser -----

/**
 * Normalizuje assert vstup pre formát `assert: |`.
 * Každý neprázdny riadok je samostatná assertácia.
 */
function normalizeAssertionsInput(assertions) {
  if (assertions == null) return [];
  if (typeof assertions !== "string") return null;

  return assertions
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line !== "");
}

/**
 * Rozdelí argumenty volania po čiarkach.
 * Rešpektuje úvodzovky a vnorené (), [], {}.
 */
function splitAssertionArgs(argsStr) {
  const result = [];
  let current = "";
  let inQuotes = false;
  let quoteChar = "";
  let roundDepth = 0;
  let squareDepth = 0;
  let curlyDepth = 0;

  for (let i = 0; i < argsStr.length; i++) {
    const ch = argsStr[i];

    if (inQuotes) {
      if (ch === "\\" && i + 1 < argsStr.length) {
        current += ch + argsStr[i + 1];
        i += 1;
        continue;
      }
      if (ch === quoteChar) {
        inQuotes = false;
      }
      current += ch;
      continue;
    }

    if (ch === '"' || ch === "'") {
      inQuotes = true;
      quoteChar = ch;
      current += ch;
      continue;
    }

    if (ch === "(") roundDepth += 1;
    else if (ch === ")") roundDepth = Math.max(0, roundDepth - 1);
    else if (ch === "[") squareDepth += 1;
    else if (ch === "]") squareDepth = Math.max(0, squareDepth - 1);
    else if (ch === "{") curlyDepth += 1;
    else if (ch === "}") curlyDepth = Math.max(0, curlyDepth - 1);

    if (ch === "," && roundDepth === 0 && squareDepth === 0 && curlyDepth === 0) {
      result.push(current.trim());
      current = "";
      continue;
    }

    current += ch;
  }

  const last = current.trim();
  if (last !== "" || result.length > 0) {
    result.push(last);
  }
  return result;
}

function isQuotedLiteral(token) {
  if (!token || token.length < 2) return false;
  const first = token[0];
  const last = token[token.length - 1];
  return (first === '"' && last === '"') || (first === "'" && last === "'");
}

function parseQuotedLiteral(token) {
  if (token[0] === '"') {
    return JSON.parse(token);
  }

  // Single-quoted string podporujeme pre YAML-štýl zápis argumentov.
  const body = token.slice(1, -1);
  return body.replace(/\\'/g, "'").replace(/\\\\/g, "\\");
}

function isNumericLiteral(token) {
  return /^[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?$/.test(token);
}

function tryGetPathValue(source, pathParts) {
  if (!source || typeof source !== "object") {
    return { found: false, value: undefined };
  }

  let cursor = source;
  for (const part of pathParts) {
    if (cursor == null || (typeof cursor !== "object" && typeof cursor !== "function")) {
      return { found: false, value: undefined };
    }

    if (!(part in cursor)) {
      return { found: false, value: undefined };
    }

    cursor = cursor[part];
  }

  return { found: true, value: cursor };
}

function resolveTokenPath(token, scope) {
  const pathParts = token
    .split(".")
    .map((part) => part.trim())
    .filter(Boolean);

  if (pathParts.length === 0) {
    return { found: false, value: undefined };
  }

  const rootScope = scope && typeof scope === "object" ? scope : {};

  // 1) Priamy lookup zo scope root (napr. stepIndex, data.foo)
  const direct = tryGetPathValue(rootScope, pathParts);
  if (direct.found) return direct;

  // 2) Lookup cez data-mapu (najčastejší prípad pre unquoted dotted keys)
  const fromData = tryGetPathValue(rootScope.data, pathParts);
  if (fromData.found) return fromData;

  // 3) Lookup v aktuálnom kroku (step.xxx)
  const fromStep = tryGetPathValue(rootScope.step, pathParts);
  if (fromStep.found) return fromStep;

  // 4) Lookup v map
  if (rootScope.map && typeof rootScope.map === "object" && token in rootScope.map) {
    return { found: true, value: rootScope.map[token] };
  }

  const fromMap = tryGetPathValue(rootScope.map, pathParts);
  if (fromMap.found) return fromMap;

  return { found: false, value: undefined };
}

function evaluateAssertionArg(token, scope) {
  const text = token == null ? "" : String(token).trim();
  if (text === "") return "";
  if (isQuotedLiteral(text)) return parseQuotedLiteral(text);
  if (text === "true") return true;
  if (text === "false") return false;
  if (text === "null") return null;
  if (isNumericLiteral(text)) return Number(text);

  const resolved = resolveTokenPath(text, scope);
  if (resolved.found) {
    return resolved.value;
  }

  // Zachovanie spätnej kompatibility: neresolvnute unquoted tokeny berieme ako plain string.
  return text;
}

/**
 * Parsuje jeden záznam assertácie. Prijíma:
 *   - string:  "isEqual(foo, bar)"  →  { fn: "isEqual", args: [fooValue, barValue], raw: "..." }
 * Vráti null pri nevalidnom vstupe.
 */
function parseAssertion(input, scope) {
  if (typeof input !== "string") return null;

  const raw = input.trim();
  const match = raw.match(/^(\w+)\s*\(([\s\S]*)\)\s*$/);
  if (!match) return null;

  const fn = match[1];
  const argsStr = match[2].trim();
  const tokens = argsStr === "" ? [] : splitAssertionArgs(argsStr);
  const args = [];

  for (const token of tokens) {
    try {
      args.push(evaluateAssertionArg(token, scope));
    } catch (e) {
      return {
        fn,
        args: [],
        raw,
        error: `Nevalidný argument "${token}": ${String(e)}`,
      };
    }
  }

  return { fn, args, raw };
}

// ----- Assertions -----

const ALF_ASSERTIONS = {
  /** Používateľ je prihlásený (existuje tlačidlo "odhlasit").
   *  Ak je zadaný user, hľadá sa jeho meno v hlavičke `.idsk-header__user.main`. */
  isAuthenticated(user) {
    const logoutBtn = document.querySelector('[data-test-id="odhlasit"]');
    if (!logoutBtn) return false;

    if (user == null || !String(user).trim()) {
      return true;
    }

    const normalize = (value) =>
      String(value || "")
        .trim()
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");

    const needle = normalize(user);
    const userEls = document.querySelectorAll(".idsk-header__user.main");

    for (const el of userEls) {
      const text = normalize(el.textContent);
      if (text.includes(needle)) return true;
    }

    return false;
  },

  /** Používateľ NIE je prihlásený – existuje tlačidlo prihlásenia alebo registrácie. */
  isUnauthenticated() {
    return !!(
      document.querySelector('[data-test-id="prihlasenie"]') ||
      document.querySelector('[data-test-id="registracia"]')
    );
  },

  /** Aktuálna URL sedí na zadaný vzor (rovnaký wildcard formát ako kroky scenára). */
  urlMatches(url) {
    if (!url) return false;
    // urlMatchesStep je definovaná v main.js, zdieľaný scope (late binding).
    return urlMatchesStep(location.href, String(url).trim());
  },

  /** Element je zaškrtnutý / aria-checked=true / má truthy hodnotu. */
  isTrue(testId) {
    const el = alfRequireEl(testId, "isTrue");
    if (el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio")) {
      return el.checked;
    }
    const ariaChecked = el.getAttribute("aria-checked");
    if (ariaChecked !== null) return ariaChecked === "true";
    const val = alfGetElValue(el);
    return Boolean(val) && val !== "false" && val !== "0";
  },

  /** Opak isTrue. */
  isFalse(testId) {
    const el = alfRequireEl(testId, "isFalse");
    if (el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio")) {
      return !el.checked;
    }
    const ariaChecked = el.getAttribute("aria-checked");
    if (ariaChecked !== null) return ariaChecked !== "true";
    const val = alfGetElValue(el);
    return !val || val === "false" || val === "0";
  },

  /** Hodnota (alebo textContent) elementu sa rovná zadanému reťazcu. */
  isEqual(testId, value) {
    const el = alfRequireEl(testId, "isEqual");
    return alfGetElValue(el) === String(value != null ? value : "");
  },

  /** Opak isEqual. */
  isNotEqual(testId, value) {
    const el = alfRequireEl(testId, "isNotEqual");
    return alfGetElValue(el) !== String(value != null ? value : "");
  },

  /** Element má prázdnu hodnotu / text. */
  isEmpty(testId) {
    const el = alfRequireEl(testId, "isEmpty");
    return alfGetElValue(el) === "";
  },

  /** Opak isEmpty. */
  isNotEmpty(testId) {
    const el = alfRequireEl(testId, "isNotEmpty");
    return alfGetElValue(el) !== "";
  },

  /** Presná zhoda textu v <title>. */
  titleIs(text) {
    if (text == null) return false;
    return document.title.trim() === String(text).trim();
  },

  /** Presná zhoda textu v jedinom <h1>. Musí existovať práve jeden h1 element. */
  h1Is(text) {
    const headingEls = Array.from(document.querySelectorAll("h1"));
    if (headingEls.length !== 1) {
      throw new Error(`h1Is assertion failed: expected exactly one h1, found ${headingEls.length}`);
    }
    if (text == null) return false;
    return headingEls[0].textContent.trim() === String(text).trim();
  },

  /** Breadcrumbs podľa viditeľného textu v poradí (exact match). */
  breadcrumbsAre(...paths) {
    const expected = paths
      .map((p) => (p == null ? "" : String(p).trim()))
      .filter((p) => p !== "");
    if (expected.length === 0) return false;

    const root = document.querySelector(".govuk-breadcrumbs__list");
    if (!root) return false;

    const actual = Array.from(root.querySelectorAll(".govuk-breadcrumbs__list-item"))
      .map((item) => {
        const labelEl = item.querySelector("a, span");
        return (labelEl ? labelEl.textContent : item.textContent || "").trim();
      })
      .filter((v) => v !== "");

    if (actual.length !== expected.length) return false;
    for (let i = 0; i < expected.length; i++) {
      if (actual[i] !== expected[i]) return false;
    }
    return true;
  },

  /** Toast/alert s success triedou (voliteľne obsahujúci daný text). */
  hasSuccessMessage(text) {
    const all = Array.from(
      document.querySelectorAll(
        '[role="alert"], .toast, .notification, [class*="toast"], [class*="notification"], [class*="snackbar"]',
      ),
    );
    const pool = all.filter((el) => {
      const cls = (el.className || "").toLowerCase();
      return (
        cls.includes("success") ||
        cls.includes("is-success") ||
        el.dataset.type === "success"
      );
    });
    const candidates = pool.length > 0 ? pool : all;
    if (!text) return candidates.length > 0;
    const needle = String(text).trim().toLowerCase();
    return candidates.some((el) => el.textContent.trim().toLowerCase().includes(needle));
  },

  /** Toast/alert s error triedou alebo .govuk-error-summary (voliteľne obsahujúci text). */
  hasErrorMessage(text) {
    const all = Array.from(
      document.querySelectorAll(
        '[role="alert"], .govuk-error-summary, .toast, [class*="toast"], [class*="error"], [class*="notification"]',
      ),
    );
    const pool = all.filter((el) => {
      const cls = (el.className || "").toLowerCase();
      return (
        cls.includes("error") ||
        cls.includes("is-error") ||
        el.dataset.type === "error"
      );
    });
    const candidates = pool.length > 0 ? pool : all;
    if (!text) return candidates.length > 0;
    const needle = String(text).trim().toLowerCase();
    return candidates.some((el) => el.textContent.trim().toLowerCase().includes(needle));
  },

  /** V govuk-form-group rodičovi poľa existuje chybová hláška (voliteľne s textom). */
  hasValidationError(testId, text) {
    const el = alfRequireEl(testId, "hasValidationError");
    const parent =
      el.closest(".govuk-form-group, .form-group, .field, .input-wrapper") ||
      el.parentElement;
    if (!parent) return false;
    const errorEl = parent.querySelector(
      '.govuk-error-message, .error-message, .field-error, [class*="error-message"], [class*="validation-error"]',
    );
    if (!errorEl) return false;
    if (!text) return true;
    return errorEl.textContent
      .trim()
      .toLowerCase()
      .includes(String(text).trim().toLowerCase());
  },

  /** Počet elementov s daným data-test-id sedí. */
  countByTestIdIs(testId, number) {
    alfRequireEl(testId, "countByTestIdIs");
    const key = String(testId);
    const escaped = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(key) : key;
    return (
      document.querySelectorAll(`[data-test-id="${escaped}"]`).length === Number(number)
    );
  },

  /** Počet výskytov textu vo viditeľnom texte stránky sedí (case-insensitive). */
  textCount(text, number) {
    const needleRaw = String(text == null ? "" : text).trim();
    if (!needleRaw) return false;

    const bodyText = document.body && typeof document.body.innerText === "string"
      ? document.body.innerText
      : "";

    const haystack = bodyText.toLowerCase();
    const needle = needleRaw.toLowerCase();
    let count = 0;
    let startIndex = 0;

    while (startIndex < haystack.length) {
      const foundAt = haystack.indexOf(needle, startIndex);
      if (foundAt === -1) break;
      count += 1;
      startIndex = foundAt + needle.length;
    }

    return count === Number(number);
  },

  /** Element existuje a je viditeľný. */
  isVisible(testId) {
    const el = alfRequireEl(testId, "isVisible");
    return alfIsVisible(el);
  },

  /** Element existuje a je povolený. */
  isEnabled(testId) {
    const el = alfRequireEl(testId, "isEnabled");
    if ("disabled" in el) {
      return !el.disabled;
    }
    return el.getAttribute("aria-disabled") !== "true";
  },

  /** Element existuje a je zablokovaný. */
  isDisabled(testId) {
    const el = alfRequireEl(testId, "isDisabled");
    if ("disabled" in el) {
      return !!el.disabled;
    }
    return el.getAttribute("aria-disabled") === "true";
  },

  /** Element existuje a obsahuje text (case-insensitive). */
  textContains(testId, text) {
    const el = alfRequireEl(testId, "textContains");
    const needle = String(text == null ? "" : text).trim().toLowerCase();
    if (!needle) return false;
    return alfGetElValue(el).toLowerCase().includes(needle);
  },

  /** Element s daným data-test-id existuje v DOM (alias pre "identifikator"). */
  elementExists(testId) {
    return alfExists(testId);
  },
};

// ----- Runner -----

/**
 * Spustí assertácie z formátu `assert: |`.
 * Každý neprázdny riadok block-stringu je samostatná assertácia.
 *
 * Vráti { passed: bool, results: [{ fn, args, passed, error?, raw? }] }
 */
function runAssertions(assertions, context) {
  const normalized = normalizeAssertionsInput(assertions);

  if (normalized == null) {
    return {
      passed: false,
      results: [
        {
          fn: "",
          args: [],
          passed: false,
          error: "Nevalidný formát assert. Očakáva sa `assert: |` (string).",
          raw: typeof assertions === "string" ? assertions : JSON.stringify(assertions),
        },
      ],
    };
  }

  if (normalized.length === 0) {
    return { passed: true, results: [] };
  }

  const results = normalized.map((entry) => {
    const parsed = parseAssertion(entry, context);
    if (!parsed) {
      return {
        fn: "",
        args: [],
        passed: false,
        error: "Nevalidný syntax assertácie",
        raw: entry,
      };
    }

    if (parsed.error) {
      return {
        fn: parsed.fn,
        args: [],
        passed: false,
        error: parsed.error,
        raw: parsed.raw,
      };
    }

    const fn = ALF_ASSERTIONS[parsed.fn];
    if (typeof fn !== "function") {
      return {
        fn: parsed.fn,
        args: parsed.args,
        passed: false,
        error: `Neznáma assertácia: "${parsed.fn}"`,
        raw: parsed.raw,
      };
    }

    try {
      return {
        fn: parsed.fn,
        args: parsed.args,
        passed: !!fn(...parsed.args),
        raw: parsed.raw,
      };
    } catch (e) {
      const errorText = e && typeof e === "object" && "message" in e ? e.message : String(e);
      return {
        fn: parsed.fn,
        args: parsed.args,
        passed: false,
        error: String(errorText),
        raw: parsed.raw,
      };
    }
  });

  return { passed: results.every((r) => r.passed), results };
}
