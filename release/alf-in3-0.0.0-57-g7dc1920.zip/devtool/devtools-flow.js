// Scenario loading and step execution flow for ALF DevTools.
let lastScenario = null;
let lastScenarioIndex = -1;
let lastScenarioFilePath = null;
const STEP_MODE_ACTION = "action";
const STEP_MODE_ASSERT = "assert";
let currentStepMode = STEP_MODE_ACTION;
const lastAssertResultsByStep = new Map();

function getStepAssertionLines(step) {
  if (!step || typeof step !== "object") return [];
  if (typeof step.assert === "string") {
    return step.assert.split(/\r?\n/).map((line) => line.trim()).filter((line) => line !== "");
  }
  if (Array.isArray(step.assert)) {
    return step.assert.map((entry) => String(entry).trim()).filter((line) => line !== "");
  }
  return [];
}

function stepHasAssertions(step) {
  return getStepAssertionLines(step).length > 0;
}

function setPrimaryButtonMode(mode) {
  currentStepMode = mode === STEP_MODE_ASSERT ? STEP_MODE_ASSERT : STEP_MODE_ACTION;
  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (!runScenarioStepBtn) return;
  runScenarioStepBtn.textContent = currentStepMode === STEP_MODE_ASSERT ? "Assert" : "Action";
  runScenarioStepBtn.classList.toggle("mode-assert", currentStepMode === STEP_MODE_ASSERT);
}

function updateActionButtonState() {
  const runScenarioStepBtn = $("runScenarioStepBtn");
  const resetScenarioBtn = $("resetScenarioBtn");
  const apiSelect = $("apiSelect");
  if (!runScenarioStepBtn && !resetScenarioBtn) return;

  if (!apiSelect || !apiSelect.value || !String(apiSelect.value).trim()) {
    if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
    if (resetScenarioBtn) resetScenarioBtn.disabled = true;
    return;
  }

  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
    if (resetScenarioBtn) resetScenarioBtn.disabled = true;
    return;
  }

  if (runScenarioStepBtn) runScenarioStepBtn.disabled = false;
  if (resetScenarioBtn) resetScenarioBtn.disabled = false;
}

function getDelayMsForStep(step) {
  if (!step || typeof step !== "object") return 500;
  const mapKeys = step.map && typeof step.map === "object" ? Object.keys(step.map) : [];
  const hasDelayedKeys = mapKeys.some((k) => /#toggle/i.test(String(k)) || /#search/i.test(String(k)));
  if (hasDelayedKeys) return 2000;
  if (mapKeys.length > 0) return 1000;
  return 500;
}

function applyDelayForCurrentStep() {
  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    updateActionButtonState();
    return;
  }
  const step = lastScenario[lastScenarioIndex];
  const delayMs = getDelayMsForStep(step);
  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  if (delayMs > 0) setTimeout(() => updateActionButtonState(), delayMs);
  else updateActionButtonState();
}

function renderAssertionResults(assertResults) {
  const section = $("assertSection");
  const container = $("assertResult");
  const summary = $("assertSummary");
  if (!section || !container) return;

  if (!assertResults || !Array.isArray(assertResults.results)) {
    section.style.display = "none";
    return;
  }

  const results = assertResults.results;
  if (results.length === 0) {
    if (summary) {
      summary.textContent = "(0/0)";
      summary.style.color = "#9ca3af";
    }
    container.innerHTML = "";
    const div = document.createElement("div");
    div.className = "assert-item";
    div.textContent = "No assertions for this step.";
    container.appendChild(div);
    section.style.display = "block";
    return;
  }

  const passedCount = results.filter((r) => r.passed).length;
  const total = results.length;
  if (summary) {
    summary.textContent = `(${passedCount}/${total})`;
    summary.style.color = passedCount === total ? "#3fb950" : "#f85149";
  }

  container.innerHTML = "";
  for (const r of results) {
    const div = document.createElement("div");
    div.className = `assert-item ${r.passed ? "pass" : "fail"}`;
    const icon = r.passed ? "✓" : "✗";
    const label = r.raw || (r.fn ? `${r.fn}(${(r.args || []).join(", ")})` : "(neznáma assertácia)");
    const err = r.error ? ` — ${r.error}` : "";
    div.textContent = `${icon} ${label}${err}`;
    container.appendChild(div);
  }

  section.style.display = "block";
}

function renderAssertionPreview(step) {
  const section = $("assertSection");
  const container = $("assertResult");
  const summary = $("assertSummary");
  if (!section || !container) return;

  const lines = getStepAssertionLines(step);
  if (lines.length === 0) {
    renderAssertionResults({ passed: true, results: [] });
    return;
  }

  if (summary) {
    summary.textContent = `(0/${lines.length}) pending`;
    summary.style.color = "#9ca3af";
  }

  container.innerHTML = "";
  for (const line of lines) {
    const div = document.createElement("div");
    div.className = "assert-item";
    div.textContent = `- ${line}`;
    container.appendChild(div);
  }

  section.style.display = "block";
}

function syncCurrentStepModeAndAssertions() {
  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    setPrimaryButtonMode(STEP_MODE_ACTION);
    renderAssertionResults(null);
    updateActionButtonState();
    return;
  }

  const step = lastScenario[lastScenarioIndex] || {};
  const hasAsserts = stepHasAssertions(step);
  const cachedResults = lastAssertResultsByStep.get(lastScenarioIndex) || null;

  if (hasAsserts) {
    if (cachedResults) {
      setPrimaryButtonMode(STEP_MODE_ACTION);
      renderAssertionResults(cachedResults);
    } else {
      setPrimaryButtonMode(STEP_MODE_ASSERT);
      renderAssertionPreview(step);
    }
  } else {
    setPrimaryButtonMode(STEP_MODE_ACTION);
    renderAssertionResults({ passed: true, results: [] });
  }

  updateActionButtonState();
}

function renderCurrentStepInfo(indexOverride) {
  const apiResult = $("apiResult");
  if (!apiResult) return;

  if (!Array.isArray(lastScenario) || lastScenario.length === 0) {
    apiResult.textContent = "Žiadny načítaný scenár.";
    return;
  }

  const totalSteps = lastScenario.length;
  const idx = typeof indexOverride === "number" && !Number.isNaN(indexOverride) ? indexOverride : lastScenarioIndex;
  if (idx < 0 || idx >= totalSteps) {
    apiResult.textContent = "Žiadne ďalšie kroky scenára.";
    return;
  }

  const step = lastScenario[idx] || {};
  const actionName = step.action || step.actions || null;
  const map = step.map && typeof step.map === "object" ? step.map : null;

  const lines = [
    `Step ${idx + 1}/${totalSteps}`,
    `name: ${step.name || "-"}`,
    `url: ${step.url || "-"}`,
    `action: ${actionName || "-"}`,
  ];

  const assertLines = getStepAssertionLines(step);
  if (assertLines.length > 0) {
    if (typeof step.assert === "string") {
      lines.push("assert: |");
      for (const line of assertLines) lines.push(`  ${line}`);
    } else {
      lines.push("assert:");
      for (const line of assertLines) lines.push(`  - ${line}`);
    }
  }

  if (map && Object.keys(map).length > 0) {
    lines.push("map:");
    for (const [k, v] of Object.entries(map)) {
      const valStr = v === null || v === undefined ? "" : String(v);
      lines.push(`  ${k}: ${valStr}`);
    }
  } else {
    lines.push("map: (žiadne položky)");
  }

  apiResult.textContent = lines.join("\n");
}

function extractScenarios(result) {
  if (!result || typeof result !== "object") return null;
  const feature = (result.feature && typeof result.feature === "object" && result.feature) || (result.alf && typeof result.alf === "object" && result.alf) || null;
  if (!feature || !Array.isArray(feature.scenario)) return null;
  return feature.scenario;
}

function getStartUrl(result) {
  if (!result || typeof result !== "object") return null;
  let pathOrUrl = null;
  if (result.feature && typeof result.feature === "object" && result.feature.start && typeof result.feature.start === "object" && typeof result.feature.start.url === "string") {
    pathOrUrl = result.feature.start.url.trim();
  }
  if (!pathOrUrl && typeof result.startUrl === "string") pathOrUrl = result.startUrl.trim();
  if (!pathOrUrl && result.feature?.startUrl) pathOrUrl = String(result.feature.startUrl).trim();
  if (!pathOrUrl && result.alf?.startUrl) pathOrUrl = String(result.alf.startUrl).trim();
  return pathOrUrl || null;
}

async function loadScenario() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const presetSelect = $("presetSelect");
  const filePath = apiSelect.value;
  const presetName = presetSelect ? presetSelect.value : "";

  if (!filePath) {
    apiResult.textContent = "";
    return;
  }
  if (!presetName) {
    apiResult.textContent = "Vyber preset, aby sa dal načítať scenár.";
    alfLog("warn", "ALF DevTools – scenár sa nenačítal, chýba preset.");
    return;
  }
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) {
    apiResult.textContent = "";
    return;
  }

  try {
    const result = await postAlfScenario(baseUrl, filePath, presetName);
    const scenarios = extractScenarios(result);
    if (!scenarios || scenarios.length === 0) return;

    const startObj = (result && result.start) || (result && result.alf && result.alf.start) || (result && result.feature && result.feature.start) || null;
    const combinedSteps = [];
    if (startObj && typeof startObj === "object") {
      combinedSteps.push({
        name: startObj.name || "start",
        url: (typeof startObj.url === "string" && startObj.url) || getStartUrl(result) || null,
        action: startObj.action || startObj.actions || null,
        map: startObj.map || null,
      });
    }
    for (const s of scenarios) {
      if (s && typeof s === "object") combinedSteps.push(s);
    }

    lastScenario = combinedSteps;
    lastScenarioFilePath = filePath;
    lastScenarioIndex = 0;
    lastAssertResultsByStep.clear();

    renderCurrentStepInfo(0);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();

    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;

      if (chrome.action && tabId != null && totalSteps) {
        chrome.action.setBadgeBackgroundColor({ color: "#2563eb", tabId });
        chrome.action.setBadgeText({ text: `0/${totalSteps}`, tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge && totalSteps) stepBadge.textContent = `0/${totalSteps}`;
    } catch (e) {
      alfLog("warn", "ALF DevTools – nepodarilo sa nastaviť badge:", e && e.message ? e.message : e);
    }

    const startUrl = getStartUrl(result);
    let presetUrl = null;
    let targetOrigin = null;
    if (presetName && currentPresetsMap.has(presetName)) {
      const preset = currentPresetsMap.get(presetName);
      if (preset.env) {
        let envUrl = preset.env.trim();
        if (!envUrl.startsWith("http")) envUrl = "https://" + envUrl;
        try {
          presetUrl = envUrl;
          targetOrigin = new URL(envUrl).origin;
        } catch {}
      }
    }

    if (!startUrl) {
      if (presetUrl) {
        try {
          const inspected = chrome.devtools?.inspectedWindow;
          const tabId = inspected?.tabId;
          if (tabId != null) chrome.tabs.update(tabId, { url: presetUrl });
        } catch {}
      }
      return;
    }

    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      if (tabId != null) {
        if (!targetOrigin) {
          const currentHrefResult = await getInspectedTabUrl().catch(() => null);
          if (currentHrefResult) {
            try {
              const current = new URL(currentHrefResult);
              targetOrigin = current.origin;
            } catch {
              targetOrigin = null;
            }
          }
        }
        let targetUrl;
        if (startUrl.startsWith("http") || !targetOrigin) {
          targetUrl = startUrl;
        } else {
          const path = String(startUrl).trim();
          targetUrl = path.startsWith("/") ? targetOrigin + path : targetOrigin + "/" + path;
        }
        chrome.tabs.update(tabId, { url: targetUrl });
      }
    } catch (navErr) {
      alfLog("warn", "ALF DevTools – nepodarilo sa presmerovať stránku:", navErr && navErr.message ? navErr.message : navErr);
    }
  } catch (e) {
    alfLog("error", "ALF DevTools – chyba POST getAlfScenario:", e && e.message ? e.message : e);
    apiResult.textContent = e.message || String(e);
  }
}

function getCurrentStepContext() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const filePath = apiSelect.value;

  if (!filePath || !lastScenario || lastScenarioFilePath !== filePath) {
    apiResult.textContent = "Vyber scenár v comboboxe – načíta sa a presmeruje na start.";
    return null;
  }

  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    apiResult.textContent = "Žiadne ďalšie kroky scenára.";
    return null;
  }

  const step = lastScenario[lastScenarioIndex];
  if (!step) {
    apiResult.textContent = "Neplatný krok scenára.";
    return null;
  }

  const inspected = chrome.devtools?.inspectedWindow;
  const tabId = inspected?.tabId;
  if (tabId == null) {
    apiResult.textContent = "TabId nie je k dispozícii.";
    return null;
  }

  return { apiResult, filePath, step, tabId };
}

async function runCurrentStepAssertions() {
  const context = getCurrentStepContext();
  if (!context) return;
  const { step, tabId } = context;
  if (!stepHasAssertions(step)) {
    setPrimaryButtonMode(STEP_MODE_ACTION);
    renderAssertionResults({ passed: true, results: [] });
    updateActionButtonState();
    return;
  }

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  alfLog("info", `ALF DevTools – runAssertions [${lastScenarioIndex + 1}] url=${step.url || "-"}`);

  chrome.tabs.sendMessage(tabId, { type: "ALF_RUN_ASSERTIONS", scenario: lastScenario, stepIndex: lastScenarioIndex }, (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "ALF DevTools – chyba pri posielaní assert správy:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      updateActionButtonState();
      return;
    }

    if (!response || !response.ok) {
      const err = response && response.error ? response.error : "Nepodarilo sa vyhodnotiť assertácie.";
      renderAssertionResults({ passed: false, results: [{ fn: "", args: [], passed: false, raw: "(assert-runtime)", error: err }] });
      setPrimaryButtonMode(STEP_MODE_ACTION);
      updateActionButtonState();
      return;
    }

    const assertResults = response.assertResults || { passed: true, results: [] };
    for (const resultItem of assertResults.results || []) {
      const info = resultItem && resultItem.info;
      if (!info) continue;
      const text = info.message || "Assertion info.";
      alfLog("warn", `ALF Assertions INFO: ${text}`, { __alfLogOptions: true, consoleOnly: true });
    }

    lastAssertResultsByStep.set(lastScenarioIndex, assertResults);
    renderAssertionResults(assertResults);
    setPrimaryButtonMode(STEP_MODE_ACTION);
    updateActionButtonState();
  });
}

async function runCurrentStepAction() {
  const context = getCurrentStepContext();
  if (!context) return;
  const { apiResult, step, tabId } = context;
  const actionName = step.action || step.actions;
  if (!actionName) {
    apiResult.textContent = "Krok scenára nemá definovanú action/actions.";
    lastScenarioIndex = Math.min(lastScenarioIndex + 1, lastScenario.length);
    renderCurrentStepInfo(lastScenarioIndex);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();
    return;
  }

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  alfLog("info", `ALF DevTools – runScenarioStep [${lastScenarioIndex + 1}] action=${actionName} url=${step.url || "-"}`);

  chrome.tabs.sendMessage(tabId, { type: "ALF_RUN_SCENARIO_ACTION", scenario: lastScenario, stepIndex: lastScenarioIndex }, (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "ALF DevTools – chyba pri posielaní správy:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      updateActionButtonState();
      return;
    }

    if (!response || !response.ok) {
      alfLog("warn", "ALF DevTools – content script nevedel spracovať action:", actionName, response);
      updateActionButtonState();
      return;
    }

    if (response.attachmentManual) {
      alfLog("info", "ALF DevTools – otvorený dialóg pre výber súboru. Vyber súbor manuálne a stlač Action.");
    }

    if (!response.found) {
      alfLog("warn", "ALF DevTools – element with data-test-id was not found:", actionName);
      updateActionButtonState();
      return;
    }

    const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;
    const nextIndex = Math.min(lastScenarioIndex + 1, totalSteps);
    try {
      if (chrome.action && totalSteps && tabId != null) {
        chrome.action.setBadgeText({ text: `${nextIndex}/${totalSteps}`, tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge && totalSteps) stepBadge.textContent = `${nextIndex}/${totalSteps}`;
    } catch (e) {
      alfLog("warn", "ALF DevTools – nepodarilo sa aktualizovať badge:", e && e.message ? e.message : e);
    }

    lastScenarioIndex = nextIndex;
    renderCurrentStepInfo(nextIndex);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();
  });
}

async function runScenarioStep() {
  if (currentStepMode === STEP_MODE_ASSERT) {
    await runCurrentStepAssertions();
    return;
  }
  await runCurrentStepAction();
}

async function resetScenario() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const filePath = apiSelect && apiSelect.value ? String(apiSelect.value) : "";

  if (!filePath || !Array.isArray(lastScenario) || lastScenarioFilePath !== filePath) {
    if (apiResult) apiResult.textContent = "Vyber scenár v comboboxe – načíta sa a presmeruje na start.";
    updateActionButtonState();
    return;
  }

  lastScenarioIndex = 0;
  lastAssertResultsByStep.clear();
  renderCurrentStepInfo(0);
  syncCurrentStepModeAndAssertions();
  applyDelayForCurrentStep();

  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    const totalSteps = lastScenario.length;
    if (chrome.action && tabId != null && totalSteps) chrome.action.setBadgeText({ text: `0/${totalSteps}`, tabId });
    const stepBadge = $("stepBadge");
    if (stepBadge && totalSteps) stepBadge.textContent = `0/${totalSteps}`;
  } catch (e) {
    alfLog("warn", "ALF DevTools – nepodarilo sa resetnúť badge:", e && e.message ? e.message : e);
  }

  try {
    const startStep = Array.isArray(lastScenario) && lastScenario.length > 0 ? lastScenario[0] : null;
    const startUrl = startStep && typeof startStep.url === "string" ? startStep.url.trim() : "";
    if (!startUrl) return;

    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;

    const currentHrefResult = await getInspectedTabUrl().catch(() => null);
    let targetOrigin = null;
    if (currentHrefResult) {
      try {
        const current = new URL(currentHrefResult);
        targetOrigin = current.origin;
      } catch {
        targetOrigin = null;
      }
    }

    let targetUrl;
    if (startUrl.startsWith("http") || !targetOrigin) {
      targetUrl = startUrl;
    } else {
      targetUrl = startUrl.startsWith("/") ? targetOrigin + startUrl : targetOrigin + "/" + startUrl;
    }

    chrome.tabs.update(tabId, { url: targetUrl });
  } catch (e) {
    alfLog("warn", "ALF DevTools – nepodarilo sa presmerovať po reset:", e && e.message ? e.message : e);
  }
}
