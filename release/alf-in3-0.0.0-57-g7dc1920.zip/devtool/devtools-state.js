// UI state and list helpers for ALF DevTools.
let currentScenariosMap = new Map();
let currentPresetsMap = new Map();
let currentBaseUrl = null;

function currentPresetValue() {
  const presetSelect = $("presetSelect");
  return presetSelect && presetSelect.value ? String(presetSelect.value).trim() : "";
}

function fillSelect(selectEl, list) {
  selectEl.innerHTML = "";
  if (selectEl.id === "apiSelect") currentScenariosMap.clear();

  if (!list || list.length === 0) {
    const opt = document.createElement("option");
    opt.value = "";
    opt.textContent = "(Žiadne položky z API)";
    selectEl.appendChild(opt);
    if (selectEl.id === "apiSelect") updateScenarioDescription();
    return;
  }

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "(Vyber scenár)";
  selectEl.appendChild(placeholder);

  for (const item of list) {
    if (!item || typeof item !== "object") continue;
    const id = item.id != null ? String(item.id) : "";
    const value = item.value != null ? String(item.value) : "";
    if (!id && !value) continue;

    if (selectEl.id === "apiSelect") currentScenariosMap.set(id, item);

    const opt = document.createElement("option");
    opt.value = id;
    opt.textContent = id.replace(/^qa\/alf\//, "").replace(/\.alf\.md$/, "");
    opt.dataset.id = id;
    selectEl.appendChild(opt);
  }

  if (selectEl.id === "apiSelect") updateScenarioDescription();
}

function updateScenarioDescription() {
  const apiSelect = $("apiSelect");
  const scenarioDescription = $("scenarioDescription");
  if (!apiSelect || !scenarioDescription) return;

  const val = apiSelect.value;
  if (!val || !currentScenariosMap.has(val)) {
    scenarioDescription.style.display = "none";
    return;
  }

  const scenario = currentScenariosMap.get(val);
  if (scenario.description) {
    scenarioDescription.textContent = scenario.description;
    scenarioDescription.style.display = "block";
  } else {
    scenarioDescription.style.display = "none";
  }
}

function updatePresetDescription() {
  const presetSelect = $("presetSelect");
  const presetDescription = $("presetDescription");
  if (!presetSelect || !presetDescription) return;

  const val = presetSelect.value;
  if (!val || !currentPresetsMap.has(val)) {
    presetDescription.style.display = "none";
    return;
  }

  const preset = currentPresetsMap.get(val);
  if (preset.description) {
    presetDescription.textContent = preset.description;
    presetDescription.style.display = "block";
  } else {
    presetDescription.style.display = "none";
  }
}

async function loadPresetsIntoSelect() {
  const presetSelect = $("presetSelect");
  if (!presetSelect) return;
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) return;

  const currentVal = presetSelect.value;
  presetSelect.innerHTML = '<option value="">(Žiadny preset)</option>';
  currentPresetsMap.clear();

  try {
    const presets = await fetchPresets(baseUrl);
    if (Array.isArray(presets)) {
      for (const preset of presets) {
        currentPresetsMap.set(preset.id, preset);
        const opt = document.createElement("option");
        opt.value = preset.id;
        opt.textContent = preset.title || preset.id;
        presetSelect.appendChild(opt);
      }
      if (currentPresetsMap.has(currentVal)) presetSelect.value = currentVal;
    }
  } catch (e) {
    alfLog("error", "ALF DevTools – chyba pri načítaní presetov:", e && e.message ? e.message : e);
  }
  updatePresetDescription();
}

async function loadSuitesIntoSelect() {
  const suiteSelect = $("suiteSelect");
  if (!suiteSelect) return;
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) return;

  const currentSuite = suiteSelect.value;
  suiteSelect.innerHTML = '<option value="">(Všetky scenáre)</option>';

  try {
    const suites = await fetchSuites(baseUrl);
    if (Array.isArray(suites)) {
      for (const suite of suites) {
        const opt = document.createElement("option");
        opt.value = suite;
        opt.textContent = suite;
        suiteSelect.appendChild(opt);
      }
      if (suites.includes(currentSuite)) suiteSelect.value = currentSuite;
    }
  } catch (e) {
    alfLog("error", "ALF DevTools – chyba pri načítaní suites:", e && e.message ? e.message : e);
  }
}

async function loadScenariosIntoSelect() {
  const apiSelect = $("apiSelect");
  const suiteSelect = $("suiteSelect");
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) return;

  const currentScenario = apiSelect ? apiSelect.value : "";
  const presetName = currentPresetValue();
  if (!presetName) {
    fillSelect(apiSelect, []);
    alfLog("info", "ALF DevTools – scenáre sa nenačítali, vyber preset.");
    return;
  }

  try {
    const suiteName = suiteSelect ? suiteSelect.value : "";
    const list = await fetchScenarios(baseUrl, suiteName);
    alfLog("info", `ALF DevTools – načítaných scenárov: ${list.length} (preset: ${presetName}${suiteName ? `, suite: ${suiteName}` : ""})`);
    fillSelect(apiSelect, list);
    if (apiSelect && currentScenario && Array.isArray(list) && list.some((item) => item && String(item.id) === String(currentScenario))) {
      apiSelect.value = currentScenario;
      updateScenarioDescription();
    }
  } catch (e) {
    alfLog("error", "ALF DevTools – chyba pri načítaní scenárov:", e && e.message ? e.message : e);
    fillSelect(apiSelect, []);
  }
}

async function loadAmsInfoIntoUi() {
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) {
    renderAmsInfo(null, "A3 URL nie je nastavené");
    return;
  }

  try {
    const amsInfo = await fetchAmsInfo(baseUrl);
    if (!amsInfo) {
      renderAmsInfo(null, "AMS endpoint vrátil prázdnu odpoveď");
      return;
    }
    renderAmsInfo(amsInfo);
  } catch (e) {
    const err = e && e.message ? e.message : String(e);
    renderAmsInfo(null, `nedostupné (${err})`);
  }
}
